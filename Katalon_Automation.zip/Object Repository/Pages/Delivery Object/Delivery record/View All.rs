<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Field Histories Column</description>
   <name>View All</name>
   <tag></tag>
   <elementGuidId>ef1af192-25f4-407a-8663-c689a60be9d1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//a[@class='slds-card__footer'])[2]/span[text()='View All']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//a[@class='slds-card__footer'])[2]/span[text()='View All']</value>
      <webElementGuid>b50dc698-c65d-46db-8805-3ed5364dbef9</webElementGuid>
   </webElementProperties>
</WebElementEntity>
