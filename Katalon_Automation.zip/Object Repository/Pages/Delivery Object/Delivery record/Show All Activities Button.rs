<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Show All Activities Button</name>
   <tag></tag>
   <elementGuidId>7db21bf8-95f2-4ff0-8a01-dcfc57b75302</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[text()='Show All Activities']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[text()='Show All Activities']</value>
      <webElementGuid>6d119fec-b751-4744-89a5-cd7ed10d67cc</webElementGuid>
   </webElementProperties>
</WebElementEntity>
