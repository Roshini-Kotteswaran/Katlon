<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Associate Name Filter on the delivery management app</description>
   <name>Associate Name Filter</name>
   <tag></tag>
   <elementGuidId>dcc470f1-ca97-47b1-b3bb-952daf0aae03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@class='slds-input'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@class='slds-input'])[2]</value>
      <webElementGuid>f18ea6e1-d385-4303-ad66-b69abab0c02c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
