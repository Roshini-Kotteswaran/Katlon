<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>deliver app record type value</name>
   <tag></tag>
   <elementGuidId>31036f84-b548-4dfc-9b18-0b556ff2e977</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//table[contains(@class, 'slds-table_cell-buffer')]//tbody/tr/td[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//table[contains(@class, 'slds-table_cell-buffer')]//tbody/tr/td[3]</value>
      <webElementGuid>0277b692-303f-478f-bf7e-576aa3004193</webElementGuid>
   </webElementProperties>
</WebElementEntity>
