<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Asscociate name column link on the delivery management app.</description>
   <name>Associate Name Link DM App</name>
   <tag></tag>
   <elementGuidId>157d34c9-3389-460a-9662-dc2229918a1d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//a[contains(@href,'view')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//a[contains(@href,'view')])[2]</value>
      <webElementGuid>d14a64bf-bcfe-49e2-bcc8-653483ec3e1a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
