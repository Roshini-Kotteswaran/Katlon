<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Login Global Search bar</name>
   <tag></tag>
   <elementGuidId>a2c0f35d-b095-4de0-a037-cbb8235f7dd0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@aria-label='Search']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@aria-label='Search']</value>
      <webElementGuid>b3a2c0b3-aad0-4799-8764-39289e565dd2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
