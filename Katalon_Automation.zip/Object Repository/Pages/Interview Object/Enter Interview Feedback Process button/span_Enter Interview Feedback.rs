<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Enter Interview Feedback</name>
   <tag></tag>
   <elementGuidId>1bfbb243-d865-4ce4-87f4-10934bb814f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@title = 'Enter Interview Feedback' and (text() = 'Enter Interview Feedback' or . = 'Enter Interview Feedback')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Start Process'])[2]/following::span[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>adf99859-e707-47d0-b847-12df5e789aff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Enter Interview Feedback</value>
      <webElementGuid>b8ef0e32-5ad3-4a36-8846-d1ca8073f251</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-truncate</value>
      <webElementGuid>f4945a22-7455-4901-9ba0-567f636e2200</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-aura-rendered-by</name>
      <type>Main</type>
      <value>9:1658;a</value>
      <webElementGuid>0ff33493-39b8-4041-9fcc-01edfb741421</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Enter Interview Feedback</value>
      <webElementGuid>a66e424f-54a8-44c4-8b85-f2a3be189533</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;brandBand_2&quot;)/div[@class=&quot;slds-template__container&quot;]/div[@class=&quot;center oneCenterStage lafSinglePaneWindowManager&quot;]/div[@class=&quot;windowViewMode-normal oneContent active lafPageHost&quot;]/div[@class=&quot;oneRecordHomeFlexipage2Wrapper&quot;]/one-record-home-flexipage2[1]/forcegenerated-adg-rollup_component___force-generated__flexipage_-record-page___-interview_-record_-page___-interview__c___-v-i-e-w[@class=&quot;adg-rollup-wrapped&quot;]/forcegenerated-flexipage_interview_record_page_interview__c__view_js[@class=&quot;forcegenerated-flexipage-module&quot;]/record_flexipage-desktop-record-page-decorator[1]/div[@class=&quot;record-page-decorator&quot;]/records-record-layout-event-broker[1]/slot[1]/slot[1]/flexipage-record-home-template-desktop2[@class=&quot;forcegenerated-flexipage-template&quot;]/div[@class=&quot;slds-grid slds-wrap&quot;]/div[@class=&quot;slds-grid slds-wrap slds-col slds-size_1-of-1 row row-main&quot;]/div[@class=&quot;column slds-size_1-of-1 slds-medium-size_4-of-12 slds-large-size_4-of-12 region-sidebar-right&quot;]/slot[1]/flexipage-component2[1]/slot[1]/flexipage-aura-wrapper[1]/div[1]/div[@class=&quot;action-container cProcessButton&quot;]/div[@class=&quot;slds-dropdown-trigger&quot;]/div[@class=&quot;slds-dropdown slds-dropdown_right&quot;]/div[@class=&quot;slds-is-relative&quot;]/ul[@class=&quot;slds-dropdown__list&quot;]/li[@class=&quot;slds-dropdown__item&quot;]/a[1]/span[@class=&quot;slds-truncate&quot;]</value>
      <webElementGuid>cdaf8aca-8ee9-474b-98f7-66c4301eb2e5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='brandBand_2']/div/div/div[2]/div/one-record-home-flexipage2/forcegenerated-adg-rollup_component___force-generated__flexipage_-record-page___-interview_-record_-page___-interview__c___-v-i-e-w/forcegenerated-flexipage_interview_record_page_interview__c__view_js/record_flexipage-desktop-record-page-decorator/div/records-record-layout-event-broker/slot/slot/flexipage-record-home-template-desktop2/div/div[2]/div[2]/slot/flexipage-component2/slot/flexipage-aura-wrapper/div/div/div/div/div/ul/li[2]/a/span</value>
      <webElementGuid>e2d6bd76-ff16-43ab-b84d-39e2d5ceb0df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel Interview Round'])[1]/following::span[1]</value>
      <webElementGuid>846fc3e4-1662-4fce-85b1-c7f8469f1bb6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Start Process'])[2]/following::span[3]</value>
      <webElementGuid>1f22fc62-7a38-4976-b4de-64bb794099ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reschedule Interview Round'])[1]/preceding::span[1]</value>
      <webElementGuid>fc550024-97a7-4282-9586-ca5e0385165a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Schedule Next Interview Round'])[1]/preceding::span[2]</value>
      <webElementGuid>59d41b3e-1743-4649-8feb-0205ea3dcba9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Enter Interview Feedback']/parent::*</value>
      <webElementGuid>a3c1d9c5-b4e2-4e74-848b-b2ee7884e1e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//forcegenerated-flexipage_interview_record_page_interview__c__view_js/record_flexipage-desktop-record-page-decorator/div/records-record-layout-event-broker/slot/slot/flexipage-record-home-template-desktop2/div/div[2]/div[2]/slot/flexipage-component2/slot/flexipage-aura-wrapper/div/div/div/div/div/ul/li[2]/a/span</value>
      <webElementGuid>37520f95-ef24-41be-8398-d868e4b8d219</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@title = 'Enter Interview Feedback' and (text() = 'Enter Interview Feedback' or . = 'Enter Interview Feedback')]</value>
      <webElementGuid>1ae8d441-9759-4300-af8b-20a6c3b19a61</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
