<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>INT_Process button</name>
   <tag></tag>
   <elementGuidId>be4e2fa7-6c13-4dcb-9549-28511948bcc5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='Start Process'])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='Start Process'])[3]</value>
      <webElementGuid>b95ea2c5-477a-4c19-a1b4-21600e34cae7</webElementGuid>
   </webElementProperties>
</WebElementEntity>
