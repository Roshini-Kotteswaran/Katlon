<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Schedule Client Interview</name>
   <tag></tag>
   <elementGuidId>4314520d-a733-48c8-b506-8081b06868d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//span[@title = 'Schedule Client Interview' and (text() = 'Schedule Client Interview' or . = 'Schedule Client Interview')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Start Process'])[1]/following::span[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4e135fd6-bf71-4d5d-b97a-45596100a2bb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Schedule Client Interview</value>
      <webElementGuid>58aa7ca8-057c-4de7-9fe9-8d0b2be37c9b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-truncate</value>
      <webElementGuid>0e9e4724-1981-47a6-bebe-b2c4f2b2084f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-aura-rendered-by</name>
      <type>Main</type>
      <value>9:655;a</value>
      <webElementGuid>6885f13b-d14a-4ccb-982e-3f47adfe5c7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Schedule Client Interview</value>
      <webElementGuid>e55014a4-ca4c-4846-a94f-05e1f5bb8c99</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@title = 'Schedule Client Interview' and (text() = 'Schedule Client Interview' or . = 'Schedule Client Interview')]</value>
      <webElementGuid>6e6a7b00-6b24-455f-b97b-a0c0dfa2adb2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='brandBand_2']/div/div/div/div/one-record-home-flexipage2/forcegenerated-adg-rollup_component___force-generated__flexipage_-record-page___-submittal_-record_-page___-submittal__c___-v-i-e-w/forcegenerated-flexipage_submittal_record_page_submittal__c__view_js/record_flexipage-desktop-record-page-decorator/div/records-record-layout-event-broker/slot/slot/flexipage-record-home-template-desktop2/div/div[2]/div[2]/slot/flexipage-component2/slot/flexipage-aura-wrapper/div/div/div/div/div/ul/li[2]/a/span</value>
      <webElementGuid>2e9f5da2-e545-448d-bf32-aca06b25d493</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create Placement'])[1]/following::span[1]</value>
      <webElementGuid>8b6d8bb7-759f-464f-a2b8-be22a14cf6ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Start Process'])[1]/following::span[3]</value>
      <webElementGuid>94569370-cafb-48fa-b85c-6f627b8f5e92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading Actions'])[1]/preceding::span[1]</value>
      <webElementGuid>1b9dbbf6-c4ca-4f74-908d-c597da0afd54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tabs'])[3]/preceding::span[2]</value>
      <webElementGuid>1733f793-5cea-4e20-b050-6180424f2939</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Schedule Client Interview']/parent::*</value>
      <webElementGuid>079d80d2-a0c1-40d8-be1c-a36686b1148f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a/span</value>
      <webElementGuid>c4b72b40-13c0-4c23-9fdf-149b6a1c073a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@title = 'Schedule Client Interview' and (text() = 'Schedule Client Interview' or . = 'Schedule Client Interview')]</value>
      <webElementGuid>fa23834a-1778-4ff9-8724-9b2055aba7a7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
