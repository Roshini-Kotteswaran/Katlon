<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Start Process</name>
   <tag></tag>
   <elementGuidId>a0a4c3e2-807b-46d5-aedc-f5564ef66fb3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.slds-dropdown-trigger > button.slds-button.slds-button_neutral</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='Start Process'])[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='brandBand_2']/div/div/div/div/one-record-home-flexipage2/forcegenerated-adg-rollup_component___force-generated__flexipage_-record-page___-submittal_-record_-page___-submittal__c___-v-i-e-w/forcegenerated-flexipage_submittal_record_page_submittal__c__view_js/record_flexipage-desktop-record-page-decorator/div/records-record-layout-event-broker/slot/slot/flexipage-record-home-template-desktop2/div/div[2]/div[2]/slot/flexipage-component2/slot/flexipage-aura-wrapper/div/div/div/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>da77277a-2206-442b-b7b8-28d022b8c843</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-button slds-button_neutral</value>
      <webElementGuid>53d42415-5148-495f-998d-32a6f995557c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-aura-rendered-by</name>
      <type>Main</type>
      <value>555:0</value>
      <webElementGuid>dba6ba54-2a44-4175-9592-7899f16f7dc8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Start Process</value>
      <webElementGuid>52229b01-0561-4d37-bc94-7447c9891152</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='Start Process'])[2]</value>
      <webElementGuid>4416bd37-ec60-4c32-88e2-fa2c8aa74413</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='brandBand_2']/div/div/div/div/one-record-home-flexipage2/forcegenerated-adg-rollup_component___force-generated__flexipage_-record-page___-submittal_-record_-page___-submittal__c___-v-i-e-w/forcegenerated-flexipage_submittal_record_page_submittal__c__view_js/record_flexipage-desktop-record-page-decorator/div/records-record-layout-event-broker/slot/slot/flexipage-record-home-template-desktop2/div/div[2]/div[2]/slot/flexipage-component2/slot/flexipage-aura-wrapper/div/div/div/button</value>
      <webElementGuid>ddfe7212-1324-41f7-b3e6-aa86794c2667</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=','])[3]/following::button[1]</value>
      <webElementGuid>0af0e2a1-3445-417c-81a6-ce7cfc604a81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Open Ravishankar N Preview'])[3]/following::button[1]</value>
      <webElementGuid>a7d3dca4-234a-466b-82cd-ab2b5ad61857</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create Placement'])[1]/preceding::button[1]</value>
      <webElementGuid>a8377eed-f89a-4d4c-b2fe-3777f4fbd54a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//flexipage-aura-wrapper/div/div/div/button</value>
      <webElementGuid>3a6d5a3c-7659-4924-b6c7-fb665de02c3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Start Process' or . = 'Start Process')]</value>
      <webElementGuid>ed691227-fde9-498d-ab80-5e47f3099af4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
