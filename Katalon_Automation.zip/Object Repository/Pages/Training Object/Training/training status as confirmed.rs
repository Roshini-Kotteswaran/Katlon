<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>training status as confirmed</name>
   <tag></tag>
   <elementGuidId>bee10470-2dd8-4945-8cc3-54b8b2571102</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//option[text()='Confirmed']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//option[text()='Confirmed']</value>
      <webElementGuid>3c1b1e1d-dae3-42c6-afae-affd6752dc28</webElementGuid>
   </webElementProperties>
</WebElementEntity>
