<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Training status</name>
   <tag></tag>
   <elementGuidId>663651a7-377c-455e-a17f-fed3961a490c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='slds-select_container'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='slds-select_container'])[2]</value>
      <webElementGuid>e921e72d-7bb8-4356-bddc-282f52790634</webElementGuid>
   </webElementProperties>
</WebElementEntity>
