<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lightning-primitive-icon</name>
   <tag></tag>
   <elementGuidId>86a32c83-874e-429d-b888-f37d8c01dca5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//button[@class = 'slds-button slds-button_icon slds-button_icon-container'])[1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='brandBand_2']/div/div/div[3]/div/div/div/div/div[2]/div/div[3]/lightning-dual-listbox/div/div[2]/div/div[4]/lightning-button-icon/button/lightning-primitive-icon</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.slds-button.slds-button_icon.slds-button_icon-container > lightning-primitive-icon</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>lightning-primitive-icon</value>
      <webElementGuid>c5b5b4ee-fae2-4800-be81-598bc1c91cd4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//button[@class = 'slds-button slds-button_icon slds-button_icon-container'])[1]</value>
      <webElementGuid>0d6f8ce9-495d-4235-a3ac-6b7b8776e9e0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='brandBand_2']/div/div/div[3]/div/div/div/div/div[2]/div/div[3]/lightning-dual-listbox/div/div[2]/div/div[4]/lightning-button-icon/button/lightning-primitive-icon</value>
      <webElementGuid>68efd3ed-621e-45a2-98b6-855c8049db62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='United States'])[1]/following::lightning-primitive-icon[1]</value>
      <webElementGuid>4fc58244-a2b0-4c7e-822d-db91aa5e95cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='United Kingdom'])[1]/following::lightning-primitive-icon[1]</value>
      <webElementGuid>10240bf3-09fc-46a7-aa4e-fde5033ac632</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Move selection to Selected Countries'])[1]/preceding::lightning-primitive-icon[1]</value>
      <webElementGuid>ac1d6b6c-e1a2-4cd6-90cf-3fad3408187b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Move selection to Available Countires'])[1]/preceding::lightning-primitive-icon[2]</value>
      <webElementGuid>d3bec3b1-0c28-464d-83ad-5543d7b1cb45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/lightning-button-icon/button/lightning-primitive-icon</value>
      <webElementGuid>97d0235e-a57c-4637-a111-ed8f50af7a05</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
