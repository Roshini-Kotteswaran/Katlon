<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Training location</name>
   <tag></tag>
   <elementGuidId>be34a54a-7263-4871-8bef-cf90d8ebad8e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class = 'slds-select_container'])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class = 'slds-select_container'])[4]</value>
      <webElementGuid>0a13d94b-59b2-4a95-9968-9366204a1a35</webElementGuid>
   </webElementProperties>
</WebElementEntity>
