<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Active_slds-form-element__control slds-grow</name>
   <tag></tag>
   <elementGuidId>05c614cb-f484-474f-ab98-6e5a55368f20</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Active'])[1]/following::div[1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Active'])[1]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>records-record-layout-checkbox > lightning-input.slds-form-element.slds-form-element_horizontal > div.slds-form-element__control.slds-grow</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>cf534cda-39fc-44f7-8ed7-673bcb3afe13</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-form-element__control slds-grow</value>
      <webElementGuid>73955ad9-f63a-4a7d-a498-727ecc5a1f25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Active'])[1]/following::div[1]</value>
      <webElementGuid>ac3f439b-1bf3-41da-9f2a-5c0977cf9357</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sectionContent-871']/div/slot/records-record-layout-row/slot/records-record-layout-item[2]/div/span/slot/records-record-layout-checkbox/lightning-input/div</value>
      <webElementGuid>4c5c36df-1ce4-4649-b831-b2a843b4cff7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Active'])[1]/following::div[1]</value>
      <webElementGuid>2244382e-3ae4-46aa-a2fd-84e0dd43d2b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[2]/following::div[3]</value>
      <webElementGuid>c17c9069-0dae-496e-9103-bcf67b784efb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[3]/preceding::div[1]</value>
      <webElementGuid>67023efd-b22b-4895-a18d-ff3a9f36f413</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//records-record-layout-checkbox/lightning-input/div</value>
      <webElementGuid>676cbc3d-a5e1-4911-b58c-0f2d3443c8f3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
