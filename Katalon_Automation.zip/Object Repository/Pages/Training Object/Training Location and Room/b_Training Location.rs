<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_Training Location</name>
   <tag></tag>
   <elementGuidId>7dd51254-81b8-4c09-b5d9-3872b1d2abdb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='TrainingLocation__c']/div/lightning-formatted-rich-text/span/p/b</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.slds-truncate > b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>762eb42b-2fb7-4dd4-972f-e60449e6c2be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Training Location</value>
      <webElementGuid>75841654-c991-4d18-a714-4c53f1a2d8e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;TrainingLocation__c&quot;)/div[@class=&quot;slds-size_small&quot;]/lightning-formatted-rich-text[@class=&quot;al-menu-item-label slds-truncate slds-rich-text-editor__output&quot;]/span[1]/p[@class=&quot;slds-truncate&quot;]/b[1]</value>
      <webElementGuid>e400cfbe-a24b-4f1a-a6ec-1c85c3ffe3e3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='TrainingLocation__c']/div/lightning-formatted-rich-text/span/p/b</value>
      <webElementGuid>4e105a18-848d-414c-951a-fa7bf44d452b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Items'])[1]/following::b[1]</value>
      <webElementGuid>387a3295-8f9d-4863-911f-1d84eeef0731</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apps'])[1]/following::b[1]</value>
      <webElementGuid>ba99ad14-209e-41d1-a455-e23c74ec4629</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View All'])[3]/preceding::b[1]</value>
      <webElementGuid>f381fec7-fa05-44b4-b19e-70524d922555</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[1]/preceding::b[1]</value>
      <webElementGuid>b14792f6-0c0b-4981-a0b4-5d67b72e32bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Training Location']/parent::*</value>
      <webElementGuid>1e0d0730-294b-4f6b-8a28-7592d3d67fbd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/b</value>
      <webElementGuid>56dd8e61-8f03-4a27-8491-81b540bcbf55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[(text() = 'Training Location' or . = 'Training Location')]</value>
      <webElementGuid>5c84fe0d-1315-4e18-bef8-07acc0bdcdba</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
