<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mentor selection</name>
   <tag></tag>
   <elementGuidId>8a1dd5c6-f52f-4795-8a16-9a8c7e0179d0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Show All Results for ', '&quot;', 'roshini', '&quot;', '')])[1]/following::lightning-base-combobox-item[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Show All Results for ', '&quot;', 'roshini', '&quot;', '')])[1]/following::lightning-base-combobox-item[1]</value>
      <webElementGuid>1294b007-ee98-43d2-b00e-6e5174692a90</webElementGuid>
   </webElementProperties>
</WebElementEntity>
