<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>technology</name>
   <tag></tag>
   <elementGuidId>07b3cc5a-1c78-4ac3-a0c9-4cf919efa75d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@class = 'slds-combobox__input slds-input'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@class = 'slds-combobox__input slds-input'])[2]</value>
      <webElementGuid>f18905a5-678b-4313-a1a5-b4041f187c0f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
