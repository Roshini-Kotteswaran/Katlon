<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_New Technology</name>
   <tag></tag>
   <elementGuidId>6bce672c-72a0-4fd7-82d1-d1165de7ede6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Add'])[1]/following::span[2][count(. | //*[(text() = 'New Technology' or . = 'New Technology')]) = count(//*[(text() = 'New Technology' or . = 'New Technology')])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//lightning-base-combobox-item[@id='combobox-input-389-1-389']/span[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#combobox-input-389-1-389 > span.slds-media__body > span.slds-listbox__option-text.slds-listbox__option-text_entity</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6ea3e8d8-8a2a-40fc-bd39-4ea4d82104e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-listbox__option-text slds-listbox__option-text_entity</value>
      <webElementGuid>9befff1a-1a94-47ea-8284-4487b5f4ff87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New Technology</value>
      <webElementGuid>a72e1a1b-52a5-4c93-ae5e-467dc973673a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add'])[1]/following::span[2]</value>
      <webElementGuid>40ca05f5-325d-4e70-ba89-6af44f24cd18</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[@id='combobox-input-389-1-389']/span[2]/span</value>
      <webElementGuid>40b991de-c4c9-4e5a-98a9-1e0f42a58784</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add'])[1]/following::span[2]</value>
      <webElementGuid>2c502946-21a9-43be-8ce9-6f21dcbe3b23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='testing'])[1]/following::span[5]</value>
      <webElementGuid>0daf3709-7f43-44b6-b0d4-194662588219</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rpro Curriculum Id'])[1]/preceding::span[2]</value>
      <webElementGuid>ca8a1e67-8e3e-47f5-a4c4-d0a04bbd95d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/lightning-base-combobox/div/div[2]/lightning-base-combobox-item/span[2]/span</value>
      <webElementGuid>f40f4c41-1049-47df-b4e9-596aedd07ca7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'New Technology' or . = 'New Technology')]</value>
      <webElementGuid>ea1cf3ce-a86e-447e-9aa8-deb37bff59bf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
