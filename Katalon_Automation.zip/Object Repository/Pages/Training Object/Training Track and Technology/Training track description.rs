<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Training track description</name>
   <tag></tag>
   <elementGuidId>8872f13f-1af8-4627-9c59-ed97bd728df7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//textarea[@class = 'slds-textarea'])[10]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//textarea[@class = 'slds-textarea'])[10]</value>
      <webElementGuid>16971aa3-0845-4f46-9741-6aa653a5525b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
