<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_Training Track</name>
   <tag></tag>
   <elementGuidId>7dae157d-4697-49d0-b987-9dc3fe2c745e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='TrainingTrack__c']/div/lightning-formatted-rich-text/span/p/b</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.slds-truncate > b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>944baac5-8fe0-4a3e-83f7-3a1b67b093a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Training Track</value>
      <webElementGuid>16196160-fbb8-43c4-b3d2-c45f6aaf1644</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;TrainingTrack__c&quot;)/div[@class=&quot;slds-size_small&quot;]/lightning-formatted-rich-text[@class=&quot;al-menu-item-label slds-truncate slds-rich-text-editor__output&quot;]/span[1]/p[@class=&quot;slds-truncate&quot;]/b[1]</value>
      <webElementGuid>7f4fa4d5-414f-4fc6-94af-71ff57ea4800</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='TrainingTrack__c']/div/lightning-formatted-rich-text/span/p/b</value>
      <webElementGuid>f5ca72a7-e312-4554-8ccb-139b6bf3f73d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Items'])[1]/following::b[1]</value>
      <webElementGuid>ea3e0bcc-22ac-4f4e-9126-ecfa703999cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apps'])[1]/following::b[1]</value>
      <webElementGuid>b6601f7f-9b94-4226-9234-7d5b229dba79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View All'])[3]/preceding::b[1]</value>
      <webElementGuid>88e86ec3-2c00-4e7f-95ae-4b0f57ffc7eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[1]/preceding::b[1]</value>
      <webElementGuid>b71e1e90-35fd-4a2d-bcab-38f8702c43ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Training Track']/parent::*</value>
      <webElementGuid>ee9623e3-7b48-4f02-82d1-da9db845632d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/b</value>
      <webElementGuid>4e116a95-4049-4514-abc5-5bb75c457e30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[(text() = 'Training Track' or . = 'Training Track')]</value>
      <webElementGuid>07cff21f-1e49-4f36-8816-dd81560c6322</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
