<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_testing</name>
   <tag></tag>
   <elementGuidId>3f9f0dd7-18e8-457b-bdf3-f020f2b8a79e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#combobox-input-375-1-375 > span.slds-media__body > span.slds-listbox__option-text.slds-listbox__option-text_entity</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='xchange_Technology__c'])[1]/following::span[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='xchange_Technology__c'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>341ce7f1-7fe0-4801-aefb-a2bc2c64937e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-listbox__option-text slds-listbox__option-text_entity</value>
      <webElementGuid>e9961733-498e-4e53-851c-5db9acc3c210</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>testing</value>
      <webElementGuid>659d4e7e-8fea-4ce1-a1c4-7f87aa73ef56</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='xchange_Technology__c'])[1]/following::span[2]</value>
      <webElementGuid>42bcb70c-672a-4b22-9425-8c56d567dadc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[@id='combobox-input-375-1-375']/span[2]/span</value>
      <webElementGuid>6a4a20b4-a53e-47af-a05b-edd095238e6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='xchange_Technology__c'])[1]/following::span[2]</value>
      <webElementGuid>d705993e-1688-42d1-9de0-3e2bb5b3a89a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recent Technologies'])[1]/following::span[4]</value>
      <webElementGuid>5079c8fb-1c9a-4861-bfe8-398b5b542a48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/lightning-base-combobox-item/span[2]/span</value>
      <webElementGuid>3aeffdac-bdfa-44b5-9985-d4c15fec620b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'testing' or . = 'testing')]</value>
      <webElementGuid>369e3888-62e3-4f61-b0d2-8f0d4d1defec</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
