<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Start Process</name>
   <tag></tag>
   <elementGuidId>c5b88028-d62d-4eb0-8971-41b4194b1164</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='brandBand_2']/div/div/div/div/one-record-home-flexipage2/forcegenerated-adg-rollup_component___force-generated__flexipage_-record-page___-training_-record_-page___-training__c___-v-i-e-w/forcegenerated-flexipage_training_record_page_training__c__view_js/record_flexipage-desktop-record-page-decorator/div/records-record-layout-event-broker/slot/slot/flexipage-record-home-template-desktop2/div/div/slot/flexipage-component2/slot/flexipage-aura-wrapper/div/div/div/div[2]/div/div/button</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Assign Anchor'])[1]/preceding::button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.slds-dropdown-trigger > button.slds-button.slds-button_neutral</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>626a8277-69a9-4ac4-bccf-fef71bbd7057</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-button slds-button_neutral</value>
      <webElementGuid>5fbca990-a4ec-488e-b28f-185d8e20c2a0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-aura-rendered-by</name>
      <type>Main</type>
      <value>460:0</value>
      <webElementGuid>792a6dfa-9d0c-4003-93a1-c2147918b543</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Start Process</value>
      <webElementGuid>bcb5a947-a0d4-43d4-a6ca-da4a7173ca8e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assign Anchor'])[1]/preceding::button[1]</value>
      <webElementGuid>f12739ea-6f88-4545-b9e0-984bb8025ba1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='brandBand_2']/div/div/div/div/one-record-home-flexipage2/forcegenerated-adg-rollup_component___force-generated__flexipage_-record-page___-training_-record_-page___-training__c___-v-i-e-w/forcegenerated-flexipage_training_record_page_training__c__view_js/record_flexipage-desktop-record-page-decorator/div/records-record-layout-event-broker/slot/slot/flexipage-record-home-template-desktop2/div/div/slot/flexipage-component2/slot/flexipage-aura-wrapper/div/div/div/div[2]/div/div/button</value>
      <webElementGuid>cfe15297-b5f5-47d1-b8b7-99ceaff7cc3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Training'])[1]/following::button[1]</value>
      <webElementGuid>17cd5453-477a-4305-91f3-57bd929b911e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit nav items'])[1]/following::button[1]</value>
      <webElementGuid>c7d8d1f8-84fe-4581-ba1c-ffa0c2b1b556</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assign Anchor'])[1]/preceding::button[1]</value>
      <webElementGuid>c9c000ac-87dd-4c2e-aed3-4b6c45eaa5b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div/div/button</value>
      <webElementGuid>0d4f5f4a-270b-4d4d-a12a-a711cf490c32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Start Process' or . = 'Start Process')]</value>
      <webElementGuid>cc6b7790-c1d0-43e3-bdb1-aa98e1e63d41</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
