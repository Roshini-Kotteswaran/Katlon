<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_U.S. Citizen</name>
   <tag></tag>
   <elementGuidId>7651e496-5c7b-4126-934e-712c2a2e37e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@title = 'U.S. Citizen' and (text() = 'U.S. Citizen' or . = 'U.S. Citizen')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//lightning-base-combobox-item[@id='combobox-button-617-1-617']/span[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#combobox-button-617-1-617 > span.slds-media__body > span.slds-truncate</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6c7541b0-e6e1-4d7b-a7b2-bbe11ab83b39</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-truncate</value>
      <webElementGuid>04466448-13fc-4f80-a7fc-d729463fb550</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>U.S. Citizen</value>
      <webElementGuid>43c6898b-0fae-424e-a516-acf83b4ff08f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>U.S. Citizen</value>
      <webElementGuid>441c28bd-9817-4d38-a1f7-802e5c8e9c5c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[29]/following::span[3]</value>
      <webElementGuid>9654f22a-fe53-4c84-9ab8-ee0cd25ba653</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[@id='combobox-button-617-1-617']/span[2]/span</value>
      <webElementGuid>166f2404-fae6-46d4-b965-d95fe9e5104a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[29]/following::span[3]</value>
      <webElementGuid>952b696c-4a23-4667-aa12-4bc4423e2c1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[28]/following::span[8]</value>
      <webElementGuid>9f795264-7cc2-42f3-b974-2e63ee6c3f73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Green Card'])[1]/preceding::span[2]</value>
      <webElementGuid>f484f976-299f-4642-9a67-824d8a1c42eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EAD'])[1]/preceding::span[5]</value>
      <webElementGuid>f1e2dc81-c973-43cf-b36b-b0fa3ae08406</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='U.S. Citizen']/parent::*</value>
      <webElementGuid>ea083a49-4c29-4304-a5c6-94f9f0d65237</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[2]/span[2]/span</value>
      <webElementGuid>dd685b71-33c6-43de-b8d8-5ecb3c5f4da9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@title = 'U.S. Citizen' and (text() = 'U.S. Citizen' or . = 'U.S. Citizen')]</value>
      <webElementGuid>153ba240-6357-4a78-8edf-7714602bd4fa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
