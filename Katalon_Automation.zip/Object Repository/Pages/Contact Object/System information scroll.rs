<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>System information scroll</name>
   <tag></tag>
   <elementGuidId>1e7a5606-dacd-4ffb-9010-783679475e0a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='System Information'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='System Information'])[1]</value>
      <webElementGuid>26afd70a-a4ec-4bc6-8016-4d7c6126b989</webElementGuid>
   </webElementProperties>
</WebElementEntity>
