<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_United States</name>
   <tag></tag>
   <elementGuidId>a1173f1d-c5fb-4551-a84e-c3d980e03452</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@title = 'United States']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[55]/following::span[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#combobox-button-1303-1-1303 > span.slds-media__body > span.slds-truncate</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>491cfa0b-c471-4906-a6ac-f1b95bcc8bc3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-truncate</value>
      <webElementGuid>1c134644-e87c-484e-b567-dff0a117fd1a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>United States</value>
      <webElementGuid>d81b3695-3715-4975-aec2-93e632d74867</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>United States</value>
      <webElementGuid>65b26009-318d-4e20-87a3-16c55d0c6ead</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@title = 'United States']</value>
      <webElementGuid>b5d758eb-6e31-4535-8137-08629ba7a63d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[@id='combobox-button-1303-1-1303']/span[2]/span</value>
      <webElementGuid>6d1b5826-cdae-45d5-a850-09f99dc66c1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[55]/following::span[3]</value>
      <webElementGuid>765f7fe8-0a8e-46f9-9b97-daf7d992a5a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[54]/following::span[6]</value>
      <webElementGuid>2b5fdf6a-b2f7-47b9-9106-fd828220bfce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Canada'])[1]/preceding::span[2]</value>
      <webElementGuid>8cfbfda6-65a4-4525-b825-fdd7c67390dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='India'])[1]/preceding::span[5]</value>
      <webElementGuid>201b0b95-0968-4d85-9e44-cd6a75656980</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//records-record-layout-section[22]/div/div/div/slot/records-record-layout-row/slot/records-record-layout-item[2]/div/span/slot/records-record-picklist/records-form-picklist/lightning-picklist/lightning-combobox/div/lightning-base-combobox/div/div[2]/lightning-base-combobox-item[2]/span[2]/span</value>
      <webElementGuid>f97946e0-8961-4993-b089-5badec781729</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@title = 'United States' and (text() = 'United States' or . = 'United States')]</value>
      <webElementGuid>1df6ed71-0f18-41d0-9121-b7c0d9c349df</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
