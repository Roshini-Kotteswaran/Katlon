<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Submital field</name>
   <tag></tag>
   <elementGuidId>7991ef3b-b108-477f-979f-1e7a3a3395e1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(),'SUB')])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(),'SUB')])[1]</value>
      <webElementGuid>94a47963-960e-4f15-b010-b1d182554810</webElementGuid>
   </webElementProperties>
</WebElementEntity>
