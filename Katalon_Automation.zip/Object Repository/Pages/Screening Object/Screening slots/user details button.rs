<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>user details button</name>
   <tag></tag>
   <elementGuidId>08079187-9495-4f18-b46e-31056dfd6ebf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@title='User Detail']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@title='User Detail']</value>
      <webElementGuid>0a1d5d7c-9eea-4bf2-8e34-b1e7f9b05cde</webElementGuid>
   </webElementProperties>
</WebElementEntity>
