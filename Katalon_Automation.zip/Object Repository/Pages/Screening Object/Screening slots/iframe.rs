<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>iframe</name>
   <tag></tag>
   <elementGuidId>c239161e-d8e7-49ae-812d-95d86df153e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//iframe[contains(@title,'Unlimited Edition')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//iframe[contains(@title,'Unlimited Edition')]</value>
      <webElementGuid>bbf65fde-c057-4ca9-ab68-400f2177f266</webElementGuid>
   </webElementProperties>
</WebElementEntity>
