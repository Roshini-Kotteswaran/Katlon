<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>login button</name>
   <tag></tag>
   <elementGuidId>b051cfcb-a792-41ba-866a-9651ad97a05d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@name= 'login'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@name= 'login'])[1]</value>
      <webElementGuid>036037c2-72c7-4660-be55-c6cb2c7b15b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Pages/Screening Object/Screening slots/iframe</value>
      <webElementGuid>650a3028-7802-44a5-9924-8bdcc716142d</webElementGuid>
   </webElementProperties>
</WebElementEntity>
