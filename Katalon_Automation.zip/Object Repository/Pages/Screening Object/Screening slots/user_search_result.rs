<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>user_search_result</name>
   <tag></tag>
   <elementGuidId>ea19ce78-3051-4b95-b3ce-228152e7aace</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'primary slds-truncate slds-rich-text-editor__output']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class = 'primary slds-truncate slds-rich-text-editor__output']</value>
      <webElementGuid>6916fe8f-0959-4a43-8fbe-5803e019ef69</webElementGuid>
   </webElementProperties>
</WebElementEntity>
