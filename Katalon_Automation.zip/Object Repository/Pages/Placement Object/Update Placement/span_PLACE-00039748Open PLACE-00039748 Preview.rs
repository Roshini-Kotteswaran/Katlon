<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_PLACE-00039748Open PLACE-00039748 Preview</name>
   <tag></tag>
   <elementGuidId>d1c4a23b-f4bb-45d3-88b3-4c4eabbe9a8a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>lightning-primitive-cell-factory.slds-has-focus > span.slds-grid.slds-grid_align-spread</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Status'])[2]/following::span[3]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//flexipage-tab2[@id='tab-3']/slot/flexipage-component2[2]/slot/lst-related-list-container/div/div[3]/lst-related-list-single-container/laf-progressive-container/slot/lst-related-list-single-app-builder-mapper/article/lst-related-list-view-manager/lst-common-list-internal/div/div/lst-primary-display-manager/div/lst-primary-display/lst-primary-display-grid/lst-customized-datatable/div[2]/div/div/table/tbody/tr/th/lightning-primitive-cell-factory/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>afcdaee2-879d-402f-b60c-9396387e2567</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-grid slds-grid_align-spread</value>
      <webElementGuid>50464fcf-1626-4a36-a084-c9e9312ed391</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PLACE-00039748Open PLACE-00039748 Preview</value>
      <webElementGuid>8739799c-09a9-4ba5-87ca-9bcdbde2a3de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Status'])[2]/following::span[3]</value>
      <webElementGuid>cd072e37-8128-49a2-aecf-d102e3e3c22c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//flexipage-tab2[@id='tab-3']/slot/flexipage-component2[2]/slot/lst-related-list-container/div/div[3]/lst-related-list-single-container/laf-progressive-container/slot/lst-related-list-single-app-builder-mapper/article/lst-related-list-view-manager/lst-common-list-internal/div/div/lst-primary-display-manager/div/lst-primary-display/lst-primary-display-grid/lst-customized-datatable/div[2]/div/div/table/tbody/tr/th/lightning-primitive-cell-factory/span</value>
      <webElementGuid>2f706a15-213a-43e8-9cf0-082b2e1b009c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Status'])[2]/following::span[3]</value>
      <webElementGuid>8f3ac185-bd0f-4017-a234-44d2b1043603</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='End Client'])[1]/following::span[5]</value>
      <webElementGuid>4406745b-bce6-4baf-bc29-5be3d58268f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/lst-related-list-single-container/laf-progressive-container/slot/lst-related-list-single-app-builder-mapper/article/lst-related-list-view-manager/lst-common-list-internal/div/div/lst-primary-display-manager/div/lst-primary-display/lst-primary-display-grid/lst-customized-datatable/div[2]/div/div/table/tbody/tr/th/lightning-primitive-cell-factory/span</value>
      <webElementGuid>e66660af-afea-4de5-a377-ba411dbae112</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'PLACE-00039748Open PLACE-00039748 Preview' or . = 'PLACE-00039748Open PLACE-00039748 Preview')]</value>
      <webElementGuid>b08d5ddd-3a94-49cf-a39b-01a53e1fb133</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
