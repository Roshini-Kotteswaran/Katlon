<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Higher Education</name>
   <tag></tag>
   <elementGuidId>510947be-d708-41b1-bc4d-9004d0f9c65e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#combobox-button-1226-1-1226 > span.slds-media__body</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[4]/following::span[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//lightning-base-combobox-item[@id='combobox-button-1226-1-1226']/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>848df5a0-754a-4812-a2da-07d8451f735c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-media__body</value>
      <webElementGuid>456b8f34-8212-4bca-86e2-995d8556bccb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Higher Education</value>
      <webElementGuid>a50f7c15-4540-4ff4-a9ae-bcb23df9cb55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[4]/following::span[2]</value>
      <webElementGuid>54313ab9-fd02-41f5-9bb7-0d83939fff9e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[@id='combobox-button-1226-1-1226']/span[2]</value>
      <webElementGuid>bbb8fbe3-4118-4b97-8a8a-b2f31c285113</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[4]/following::span[2]</value>
      <webElementGuid>17d7c841-addf-48b1-bd8b-63d1cfcd13a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='--None--'])[3]/following::span[7]</value>
      <webElementGuid>457a1cb3-85da-4d9c-b1fd-b0a3a9f73e69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Internal Employee'])[1]/preceding::span[3]</value>
      <webElementGuid>f2d93f4a-b701-436d-bb34-2e323b6304c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//records-record-layout-row[3]/slot/records-record-layout-item/div/span/slot/records-record-picklist/records-form-picklist/lightning-picklist/lightning-combobox/div/lightning-base-combobox/div/div[2]/lightning-base-combobox-item[2]/span[2]</value>
      <webElementGuid>ad68282b-960a-4853-b708-7764c075b153</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Higher Education' or . = 'Higher Education')]</value>
      <webElementGuid>bed0a15e-a6a9-4748-abbe-7bc94ffcb54d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
