<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_On Project</name>
   <tag></tag>
   <elementGuidId>2c04c07e-e843-404d-a305-3b0b11a6e28a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#combobox-button-1212-4-1212 > span.slds-media__body</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirmed'])[1]/following::span[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//lightning-base-combobox-item[@id='combobox-button-1212-4-1212']/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7b840965-5276-4f47-8f35-5d2b0af5628e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-media__body</value>
      <webElementGuid>e641e974-e331-4be2-9c82-3689d85f57dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>On Project</value>
      <webElementGuid>9fab961f-a037-47f8-a85e-428432d883c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirmed'])[1]/following::span[2]</value>
      <webElementGuid>80d36eb1-0202-48ad-84cd-d299f5bb2447</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[@id='combobox-button-1212-4-1212']/span[2]</value>
      <webElementGuid>3ccc0883-ffeb-49b4-a581-2a9f16bb8136</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirmed'])[1]/following::span[2]</value>
      <webElementGuid>53f8d53e-894a-4e79-90dc-aad448408549</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assigned'])[4]/following::span[5]</value>
      <webElementGuid>bf488607-9316-406c-8a87-e25c7490139b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Completed'])[1]/preceding::span[3]</value>
      <webElementGuid>e324958e-6a24-4040-b16f-20a7960d5ac8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[5]/span[2]</value>
      <webElementGuid>1dc79ea9-8a3d-4015-8d90-bc22f2997ddd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'On Project' or . = 'On Project')]</value>
      <webElementGuid>2f7a362d-a82e-44b5-96b1-68fa74873929</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
