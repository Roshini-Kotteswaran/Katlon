<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_SCR-00494692Open SCR-00494692 Preview</name>
   <tag></tag>
   <elementGuidId>d2757f46-95e5-4355-9147-cc6d98cbd303</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#sectionContent-373 > div.slds-form > slot > records-record-layout-row.slds-form__row > slot.slds-grid.slds-size_1-of-1 > records-record-layout-item.slds-form__item.slds-no-space > div.slds-grid.slds-size_1-of-1.label-inline > div.slds-form-element.slds-hint-parent.test-id__output-root.slds-form-element_readonly.slds-form-element_horizontal > div.slds-form-element__control > span.test-id__field-value.slds-form-element__static.slds-grow.word-break-ie11.is-read-only</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Latest Submittal'])[1]/following::a[1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Screening'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>99fc142e-87d7-4f21-9501-58823eaec4a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>test-id__field-value slds-form-element__static slds-grow word-break-ie11 is-read-only</value>
      <webElementGuid>8bd9d041-04f0-4c61-baac-8bb7f881a47d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SCR-00494692Open SCR-00494692 Preview</value>
      <webElementGuid>c41fae5b-2eac-4012-a8a6-0badbbb4b9df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Latest Submittal'])[1]/following::a[1]</value>
      <webElementGuid>3f05fc76-977c-4438-b415-baa64ab1201b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sectionContent-373']/div/slot/records-record-layout-row/slot/records-record-layout-item/div/div/div[2]/span</value>
      <webElementGuid>6e8ecbec-29de-41d7-9382-41abc8f6e45c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Screening'])[1]/following::span[1]</value>
      <webElementGuid>0ba4154c-39b7-420f-87fa-6864da90488e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Screening'])[2]/following::span[2]</value>
      <webElementGuid>b7eb40f2-fc40-4206-8335-fb604938e5a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//records-record-layout-section[7]/div/div/div/slot/records-record-layout-row/slot/records-record-layout-item/div/div/div[2]/span</value>
      <webElementGuid>5ea6b884-08aa-4222-87b5-1163c8c44cc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'SCR-00494692Open SCR-00494692 Preview' or . = 'SCR-00494692Open SCR-00494692 Preview')]</value>
      <webElementGuid>235d4528-07a5-4c79-a02e-4bc99fb2219e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
