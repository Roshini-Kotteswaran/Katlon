<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>placement_startdate</name>
   <tag></tag>
   <elementGuidId>65105b8a-e665-4d74-84de-26522a6d4379</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[contains(@class,' input')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[contains(@class,' input')]</value>
      <webElementGuid>90f5a597-5f5a-4601-9ef0-47baf43760d7</webElementGuid>
   </webElementProperties>
</WebElementEntity>
