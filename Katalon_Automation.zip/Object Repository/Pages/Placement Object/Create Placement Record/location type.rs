<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>location type</name>
   <tag></tag>
   <elementGuidId>8d575dd6-1984-4831-98e9-456914b4c8fd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//select[@class='slds-select'])[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//select[@class='slds-select'])[5]</value>
      <webElementGuid>97cf33d2-6215-4d7c-a061-3d73dd84f32e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
