<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>client reporting manager option</name>
   <tag></tag>
   <elementGuidId>46a4dbc9-4007-4ecd-80fd-efa7726b3953</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class = 'slds-lookup__result-text'])[13]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class = 'slds-lookup__result-text'])[13]</value>
      <webElementGuid>5bfce4f9-c715-46d8-9f73-16cfe9f8154b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
