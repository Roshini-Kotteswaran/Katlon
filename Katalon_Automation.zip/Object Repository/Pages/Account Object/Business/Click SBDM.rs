<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Click SBDM</name>
   <tag></tag>
   <elementGuidId>6615ce3f-9ee2-46d0-9d8e-574d9ca0775a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@class='slds-combobox__input slds-input'])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@class='slds-combobox__input slds-input'])[3]</value>
      <webElementGuid>87a18c17-982b-4b14-b952-de8aed308d55</webElementGuid>
   </webElementProperties>
</WebElementEntity>
