<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>account name</name>
   <tag></tag>
   <elementGuidId>df80344a-3493-44e6-869d-18ca94fc3042</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@name ='Name']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@name ='Name']</value>
      <webElementGuid>d88baa50-e72f-4c6c-a668-6bf2456e498c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
