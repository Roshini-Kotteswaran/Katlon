<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSA Section table</name>
   <tag></tag>
   <elementGuidId>c24bf20a-8ba4-41c7-8bbf-aebc7cc485dc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@title='MSA']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@title='MSA']</value>
      <webElementGuid>763f6e5d-1483-467b-8796-268f3f1beef3</webElementGuid>
   </webElementProperties>
</WebElementEntity>
