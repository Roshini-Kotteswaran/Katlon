<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select account</name>
   <tag></tag>
   <elementGuidId>7ddeb87d-0666-4516-9e5d-71941dc03afc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Accounts' or . = 'Accounts')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[(text() = 'Accounts' or . = 'Accounts')]</value>
      <webElementGuid>f58dc823-cc24-4340-bb24-420713bb38b7</webElementGuid>
   </webElementProperties>
</WebElementEntity>
