<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Start Process</name>
   <tag></tag>
   <elementGuidId>2dc8ad58-fa6b-406d-858d-270dc27244da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Start Process'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='contact-header']/div/div[2]/div/div/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.slds-button.slds-button_neutral > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>8750d675-b7ab-4f3f-9a8a-e944d7ca8a3a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-aura-rendered-by</name>
      <type>Main</type>
      <value>2346:0</value>
      <webElementGuid>2162795c-8ab8-41b2-9e14-cbb6fdf071f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Start Process</value>
      <webElementGuid>79ecb54d-e1e5-4ba0-b9d8-6b7dcf4f7a01</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Start Process'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>eba7f0f4-00db-4ecd-93b2-e244a1bcd960</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='contact-header']/div/div[2]/div/div/button/span</value>
      <webElementGuid>a021d54b-f95b-468f-bc5d-8ede4be6660c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='qa1testing cont196'])[5]/following::span[1]</value>
      <webElementGuid>a2f835fa-3bfd-4069-b03e-5776b7736f2a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Preferred Name'])[2]/following::span[2]</value>
      <webElementGuid>f79a9acf-88fe-4928-9253-4e376b0d730e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Assign Training Admin'])[1]/preceding::span[1]</value>
      <webElementGuid>90549cb0-285a-4d7c-acb1-ee4909879b77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Attempt Made'])[1]/preceding::span[2]</value>
      <webElementGuid>b44a5451-c244-439e-b406-636409646f6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Start Process']/parent::*</value>
      <webElementGuid>1a42ebe5-fd83-4712-b233-86bc4d7fcbb8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//flexipage-aura-wrapper/div/div/div/div/div[2]/div/div/button/span</value>
      <webElementGuid>f4b7c9c7-2fb4-4f6f-a67d-b19e43e5af38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Start Process' or . = 'Start Process')]</value>
      <webElementGuid>b3e4c60a-d161-4cf7-8d99-2ccecc213dba</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
