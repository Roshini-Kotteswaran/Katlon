<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Finding locked screeningslot</name>
   <tag></tag>
   <elementGuidId>52d40800-219f-4571-bd74-7e784bd21fca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@class = 'fc-time']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@class = 'fc-time']</value>
      <webElementGuid>559d4aef-5aa0-4176-a4ef-942c06a8dfe5</webElementGuid>
   </webElementProperties>
</WebElementEntity>
