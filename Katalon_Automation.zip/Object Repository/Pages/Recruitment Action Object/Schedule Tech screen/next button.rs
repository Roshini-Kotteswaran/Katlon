<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>next button</name>
   <tag></tag>
   <elementGuidId>fc8196fc-821d-40ed-86fb-75cec1afdd0c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[text()='Next']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[text()='Next']</value>
      <webElementGuid>99397d03-3a67-44e2-b275-6dd9ab32c26e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
