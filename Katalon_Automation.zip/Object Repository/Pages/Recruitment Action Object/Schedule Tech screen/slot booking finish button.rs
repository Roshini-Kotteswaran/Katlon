<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>slot booking finish button</name>
   <tag></tag>
   <elementGuidId>b2e032e0-af6d-4f92-a07d-e4823d705dea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[text()='Finish']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[text()='Finish']</value>
      <webElementGuid>2b3a686c-72cc-46e8-9c57-c29b98f5ea50</webElementGuid>
   </webElementProperties>
</WebElementEntity>
