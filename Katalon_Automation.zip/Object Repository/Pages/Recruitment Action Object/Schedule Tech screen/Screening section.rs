<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Screening section</name>
   <tag></tag>
   <elementGuidId>84757a89-61f0-4bc9-a47c-8bd30c90706c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@title='Quick Links']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@title='Quick Links']</value>
      <webElementGuid>0b5736a0-b250-443f-951f-b0edf135bb21</webElementGuid>
   </webElementProperties>
</WebElementEntity>
