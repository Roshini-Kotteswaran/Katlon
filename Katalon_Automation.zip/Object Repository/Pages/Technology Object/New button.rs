<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>New button</name>
   <tag></tag>
   <elementGuidId>b6ee27a6-a171-4d1a-961b-cf4262a0ead5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@title='New'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@title='New'])[2]</value>
      <webElementGuid>29682eef-34a7-44e9-9cdf-2f0eb430a76e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
