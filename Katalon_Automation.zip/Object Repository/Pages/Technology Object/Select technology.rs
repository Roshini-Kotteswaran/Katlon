<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select technology</name>
   <tag></tag>
   <elementGuidId>ff8e1ef4-d1db-44e6-a400-8c2c45086dad</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[(text() = 'Technologies' or . = 'Technologies')])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[(text() = 'Technologies' or . = 'Technologies')])[1]</value>
      <webElementGuid>e5129b10-47f4-4bdc-af6a-47a33942d1a7</webElementGuid>
   </webElementProperties>
</WebElementEntity>
