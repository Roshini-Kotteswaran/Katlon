<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select account</name>
   <tag></tag>
   <elementGuidId>2debff6e-8030-4813-83ff-0be59900b6b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@class = 'slds-combobox__input slds-input'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@class = 'slds-combobox__input slds-input'])[1]</value>
      <webElementGuid>519b34df-6c4e-4604-9e83-1a1e6dc7db07</webElementGuid>
   </webElementProperties>
</WebElementEntity>
