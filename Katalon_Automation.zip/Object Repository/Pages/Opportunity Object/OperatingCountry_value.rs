<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>OperatingCountry_value</name>
   <tag></tag>
   <elementGuidId>0abebb0b-31fc-4bfc-a152-39529a76a05d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='United States']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='United States']</value>
      <webElementGuid>77b4976b-1fa5-4d70-b42f-f9e76eeaad41</webElementGuid>
   </webElementProperties>
</WebElementEntity>
