<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>primary contact search</name>
   <tag></tag>
   <elementGuidId>3408e6a4-a68c-4764-a714-14dfd40e1b14</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[2]/following::lightning-base-combobox-item[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[2]/following::lightning-base-combobox-item[1]</value>
      <webElementGuid>6503f11a-1dde-407e-b00f-c1d45c9c8480</webElementGuid>
   </webElementProperties>
</WebElementEntity>
