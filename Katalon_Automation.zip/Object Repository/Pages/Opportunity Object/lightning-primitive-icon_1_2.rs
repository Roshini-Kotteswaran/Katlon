<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lightning-primitive-icon_1_2</name>
   <tag></tag>
   <elementGuidId>8f2e85f2-c1a8-4f14-8a6e-7a263689e819</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous Month'])[1]/following::lightning-primitive-icon[1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous Month'])[1]/following::lightning-primitive-icon[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>lightning-primitive-icon</value>
      <webElementGuid>1c23f422-59c6-4bbb-a27c-25d101e3575f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous Month'])[1]/following::lightning-primitive-icon[1]</value>
      <webElementGuid>35cb79b7-e7b4-4684-9ed3-3412eb7ca3ef</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sectionContent-200']/div/slot/records-record-layout-row/slot/records-record-layout-item[2]/div/span/slot/lightning-input/lightning-datepicker/div/div/lightning-calendar/div/lightning-focus-trap/slot/div/div/div[2]/lightning-button-icon/button/lightning-primitive-icon</value>
      <webElementGuid>9d555928-1372-4ad1-abd5-6dc1fa67be75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='December'])[1]/following::lightning-primitive-icon[1]</value>
      <webElementGuid>fc62622a-b6f3-483b-b495-0bd6e0ec5dfc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous Month'])[1]/following::lightning-primitive-icon[1]</value>
      <webElementGuid>a67d74fd-294d-497d-9b90-9cbba3e20e3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next Month'])[1]/preceding::lightning-primitive-icon[1]</value>
      <webElementGuid>89a0fa46-1fef-4bf2-be9c-268f42d289a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pick a Year'])[1]/preceding::lightning-primitive-icon[1]</value>
      <webElementGuid>422b8f96-fa39-4a05-a8ff-2da47da7a1db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/lightning-button-icon/button/lightning-primitive-icon</value>
      <webElementGuid>23410777-0c83-469b-8ea3-fd683b62a793</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
