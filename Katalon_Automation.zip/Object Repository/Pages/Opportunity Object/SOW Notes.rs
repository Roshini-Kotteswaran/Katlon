<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SOW Notes</name>
   <tag></tag>
   <elementGuidId>4a66fb79-9345-4113-bd13-d951dcaeacc5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//textarea[@class = 'slds-textarea'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//textarea[@class = 'slds-textarea'])[2]</value>
      <webElementGuid>11d9dc83-0a58-4c31-b112-2a486acded82</webElementGuid>
   </webElementProperties>
</WebElementEntity>
