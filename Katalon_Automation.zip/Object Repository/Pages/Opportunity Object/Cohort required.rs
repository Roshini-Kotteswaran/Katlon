<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Cohort required</name>
   <tag></tag>
   <elementGuidId>f059aca5-cb36-42eb-a67b-37192227e46d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[contains(@aria-label, 'Cohort')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[contains(@aria-label, 'Cohort')]</value>
      <webElementGuid>abd78d6d-a910-48c2-bb8a-9c48c7281ce7</webElementGuid>
   </webElementProperties>
</WebElementEntity>
