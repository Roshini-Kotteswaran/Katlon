<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>opp_stage_field</name>
   <tag></tag>
   <elementGuidId>e4f64c70-f344-4d13-b70e-116ede6191b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[contains(@aria-label, 'Stage')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[contains(@aria-label, 'Stage')]</value>
      <webElementGuid>54a61525-7de6-4c7f-961a-ff5cb90ca1b0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
