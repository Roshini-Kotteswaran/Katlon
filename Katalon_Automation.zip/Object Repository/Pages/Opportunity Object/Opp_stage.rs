<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Opp_stage</name>
   <tag></tag>
   <elementGuidId>305ac257-4681-443e-8858-e2cbe697eaa5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@title='Batch Mapped']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@title='Batch Mapped']</value>
      <webElementGuid>1652cb75-1e9a-4be2-9563-f746f0eb4d4a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
