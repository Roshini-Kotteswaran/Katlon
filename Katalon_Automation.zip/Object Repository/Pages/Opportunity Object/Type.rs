<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Type</name>
   <tag></tag>
   <elementGuidId>0a9738eb-7223-4323-b847-a3ccc77a020a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//button[contains(@aria-label, 'Type')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//button[contains(@aria-label, 'Type')])[2]</value>
      <webElementGuid>5cff60a2-9009-4cae-8b48-f45d879d30a4</webElementGuid>
   </webElementProperties>
</WebElementEntity>
