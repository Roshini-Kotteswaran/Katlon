<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_TestingXperts</name>
   <tag></tag>
   <elementGuidId>81d07eda-1a16-4dd5-bf02-abd22ac28eb8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#combobox-input-461-1-461 > span.slds-media__body > span.slds-listbox__option-text.slds-listbox__option-text_entity</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(@class, 'option-text_entity')])[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>2dcc4a1c-7c2a-46be-a290-ada3bd892b15</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-listbox__option-text slds-listbox__option-text_entity</value>
      <webElementGuid>d68e373b-af98-4838-974a-da35fbfcfdf2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>TestingXperts</value>
      <webElementGuid>4e9e0e35-5fef-4b37-ab0a-b991b8c5eb27</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(@class, 'option-text_entity')])[2]</value>
      <webElementGuid>7a14463e-4f5f-44a3-b33b-385ac019a511</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[@id='combobox-input-461-1-461']/span[2]/span</value>
      <webElementGuid>ed3b5059-8966-4382-90bd-b7abb5e87fd7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::span[2]</value>
      <webElementGuid>22f16ce3-d78b-4cac-bbf0-9616a8f9725a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Show All Results for ', '&quot;', 'testing', '&quot;', '')])[1]/following::span[4]</value>
      <webElementGuid>c63832cb-b554-46b2-a9a0-caebb86003e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/lightning-base-combobox-item/span[2]/span</value>
      <webElementGuid>654ea00c-e45d-43de-896c-75f7a831a679</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'TestingXperts' or . = 'TestingXperts')]</value>
      <webElementGuid>60423245-9a12-4b2d-ae53-1aa55f22c272</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
