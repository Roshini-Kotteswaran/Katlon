<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>operating_country</name>
   <tag></tag>
   <elementGuidId>8a5efed7-e4c4-4902-b3c9-c3ee596ef6fa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[contains(@aria-label, 'Operating Country')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[contains(@aria-label, 'Operating Country')]</value>
      <webElementGuid>add00b13-c652-4100-af67-c04c7727fa30</webElementGuid>
   </webElementProperties>
</WebElementEntity>
