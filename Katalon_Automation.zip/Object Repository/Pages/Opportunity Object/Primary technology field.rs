<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Primary technology field</name>
   <tag></tag>
   <elementGuidId>14ae942b-9616-4ff0-85d1-b8fc9ebc2b69</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[contains(@aria-label, 'Primary')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[contains(@aria-label, 'Primary')]</value>
      <webElementGuid>9ac8e85a-4ef6-4cdc-8692-bf190fcf4c65</webElementGuid>
   </webElementProperties>
</WebElementEntity>
