<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Go to previous month (1)</name>
   <tag></tag>
   <elementGuidId>5df0d998-f10d-4880-9952-4af59e3c2a3e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[2]/following::a[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[2]/following::a[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.navLink.prevMonth</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2f3b947c-5571-4387-a3aa-dbc7dae0b1c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to previous month</value>
      <webElementGuid>e7fa0fb3-8611-4ec8-a6ff-76316357b07c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navLink prevMonth</value>
      <webElementGuid>3e0f9366-2de9-4c52-aa6e-d33e053acc74</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-aura-rendered-by</name>
      <type>Main</type>
      <value>541:0</value>
      <webElementGuid>b0519921-210e-4b7e-bbf3-26bd5f065779</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>javascript:void(0);</value>
      <webElementGuid>09f33400-dd8e-445c-82e6-777607893759</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Go to previous month</value>
      <webElementGuid>fd375eeb-94b4-4aca-b5fa-7ffc802d6260</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[2]/following::a[1]</value>
      <webElementGuid>c98e03a5-9db8-4b39-b75d-907a37109f2c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='535:0']/div/div/div/div/a</value>
      <webElementGuid>3597c2ce-70d0-48b5-a27b-b80c9b6f74ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[2]/following::a[1]</value>
      <webElementGuid>6693314d-55c9-4584-8123-eb640550f9bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dismiss'])[1]/following::a[1]</value>
      <webElementGuid>65cd8169-0218-4498-828f-d91fa7542025</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Go to next month'])[1]/preceding::a[1]</value>
      <webElementGuid>4bed9289-818b-4700-be2f-13a6490f3fcf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'javascript:void(0);')])[36]</value>
      <webElementGuid>4be12a02-facd-4002-9b5b-6c163f25f2dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div/div/div/div/a</value>
      <webElementGuid>b89270fa-3b33-4497-a784-90ddcdec4fed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@title = 'Go to previous month' and @href = 'javascript:void(0);' and (text() = 'Go to previous month' or . = 'Go to previous month')]</value>
      <webElementGuid>96c5adfd-5684-4beb-ae81-bc89958555aa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
