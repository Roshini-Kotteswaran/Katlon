<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Status as RQL</name>
   <tag></tag>
   <elementGuidId>11f69545-9a21-4668-bb6a-2e02d094c6fb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@title='RQL']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@title='RQL']</value>
      <webElementGuid>55ba4efa-8c94-48b6-94aa-dda9663ba8e7</webElementGuid>
   </webElementProperties>
</WebElementEntity>
