<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Computer - programming</name>
   <tag></tag>
   <elementGuidId>bab3e364-c54b-4aaa-a72c-620f6b2ce1fa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[@class = 'slds-listbox__option-text slds-listbox__option-text_entity'])[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//lightning-base-combobox-item[@id='combobox-input-1157-1-1157']/span[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#combobox-input-1157-1-1157 > span.slds-media__body > span.slds-listbox__option-text.slds-listbox__option-text_entity</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>41966421-c2f3-4c08-8ba8-5302535d2c5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-listbox__option-text slds-listbox__option-text_entity</value>
      <webElementGuid>99fbf725-171d-45d3-893f-e2f312daeeed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Computer - programming</value>
      <webElementGuid>74ac74c9-9f56-4cca-a150-99cfa3036dd4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class = 'slds-listbox__option-text slds-listbox__option-text_entity'])[2]</value>
      <webElementGuid>05058c6f-e13a-4083-b702-c1f24503ad9a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[@id='combobox-input-1157-1-1157']/span[2]/span</value>
      <webElementGuid>585792ad-114e-4117-882a-6e0c9f980b67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/lightning-base-combobox-item/span[2]/span</value>
      <webElementGuid>34dbe181-1471-4f81-969f-a9e6c3d69c47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Computer - programming' or . = 'Computer - programming')]</value>
      <webElementGuid>64bc5883-5613-4560-86c5-7c07a0052ed4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
