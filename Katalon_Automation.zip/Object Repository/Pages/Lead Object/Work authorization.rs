<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Work authorization</name>
   <tag></tag>
   <elementGuidId>319d6aa8-7002-479a-8e70-a469a3f19aa8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//button[contains(@class,'slds-combobox__input')])[12]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//button[contains(@class,'slds-combobox__input')])[12]</value>
      <webElementGuid>001a28c1-84cd-4abe-a999-d8959edf59a7</webElementGuid>
   </webElementProperties>
</WebElementEntity>
