<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select lead</name>
   <tag></tag>
   <elementGuidId>355de1ef-b785-4535-a55d-6fb2fb65cad1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//p[@class='slds-truncate'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//p[@class='slds-truncate'])[1]</value>
      <webElementGuid>c180579a-c89f-4460-91c8-ee141f469dd2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
