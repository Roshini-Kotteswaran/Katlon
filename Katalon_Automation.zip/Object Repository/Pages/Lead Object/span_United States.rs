<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_United States</name>
   <tag></tag>
   <elementGuidId>2bf7f83d-9955-46fb-a2b3-8e7fcda23c1b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@title = 'United States' and (text() = 'United States' or . = 'United States')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//lightning-base-combobox-item[@id='combobox-button-491-1-491']/span[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#combobox-button-491-1-491 > span.slds-media__body > span.slds-truncate</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>50f1cb4e-ce23-4254-8d70-e2e9a98b6661</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>slds-truncate</value>
      <webElementGuid>019842d5-1316-4c37-9b86-cc6019eb7f8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>United States</value>
      <webElementGuid>d537112e-e7bf-455d-a65f-bffa3ae4ec67</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>United States</value>
      <webElementGuid>adc38cc9-8a97-4d16-b9d3-a7b2aac92701</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@title = 'United States' and (text() = 'United States' or . = 'United States')]</value>
      <webElementGuid>0a8ddee7-1860-4808-9f46-a56259f0edd3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//lightning-base-combobox-item[@id='combobox-button-491-1-491']/span[2]/span</value>
      <webElementGuid>0deac594-697f-4596-92e5-b4ed3477fc49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//flexipage-field[14]/slot/record_flexipage-record-field/div/div/slot/records-record-picklist/records-form-picklist/lightning-picklist/lightning-combobox/div/div/lightning-base-combobox/div/div/div[2]/lightning-base-combobox-item[2]/span[2]/span</value>
      <webElementGuid>d8e4bbea-f094-4457-a1ee-7fb585ff5c52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@title = 'United States' and (text() = 'United States' or . = 'United States')]</value>
      <webElementGuid>c57de2a7-83f7-4aba-bc86-8f129d77437f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
