<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lead qualification status field</name>
   <tag></tag>
   <elementGuidId>ea9195c8-de41-421a-a12f-bd389087f479</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[contains(@aria-label,'Lead Qualification status')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[contains(@aria-label,'Lead Qualification status')]</value>
      <webElementGuid>c505c6df-512f-42ca-935f-f761f20057e2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
