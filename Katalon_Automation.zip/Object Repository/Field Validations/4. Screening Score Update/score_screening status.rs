<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>score_screening status</name>
   <tag></tag>
   <elementGuidId>b65f6bb9-ccdf-43ed-9bbd-1e75dbbadef8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[(text() = 'Completed' or . = 'Completed')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[(text() = 'Completed' or . = 'Completed')]</value>
      <webElementGuid>af86bed2-9767-4296-b4dc-caa700a483aa</webElementGuid>
   </webElementProperties>
</WebElementEntity>
