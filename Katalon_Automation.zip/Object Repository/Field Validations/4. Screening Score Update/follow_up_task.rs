<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>follow_up_task</name>
   <tag></tag>
   <elementGuidId>0228b8bb-6f0c-4199-b0d1-cff41d876ca6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(text(),'Tech Screen Follow Up')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(text(),'Tech Screen Follow Up')]</value>
      <webElementGuid>205982c3-b089-46c6-b9bc-b38b590668bd</webElementGuid>
   </webElementProperties>
</WebElementEntity>
