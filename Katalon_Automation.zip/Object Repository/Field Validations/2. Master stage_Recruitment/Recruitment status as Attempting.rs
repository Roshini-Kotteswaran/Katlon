<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Recruitment status as Attempting</name>
   <tag></tag>
   <elementGuidId>5b81affc-93f8-4c2b-b9ac-2afa88542faa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//lightning-formatted-text[text()='Attempting']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//lightning-formatted-text[text()='Attempting']</value>
      <webElementGuid>7a44c65f-7317-42ef-ad33-e68678002a22</webElementGuid>
   </webElementProperties>
</WebElementEntity>
