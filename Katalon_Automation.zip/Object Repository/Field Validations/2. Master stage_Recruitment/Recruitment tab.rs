<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Recruitment tab</name>
   <tag></tag>
   <elementGuidId>7fc80a3b-7727-44bc-bd14-9f9612a8ab1d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[text()='Recruitment']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[text()='Recruitment']</value>
      <webElementGuid>5d2f6383-76be-4c1a-85ea-ae7e1bae766c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
