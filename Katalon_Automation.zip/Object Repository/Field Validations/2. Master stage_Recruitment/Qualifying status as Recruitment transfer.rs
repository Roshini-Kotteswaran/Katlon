<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Qualifying status as Recruitment transfer</name>
   <tag></tag>
   <elementGuidId>d81ce929-bee8-4fbf-b912-75e29a8578ae</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//lightning-formatted-text[text()='Recruiter Transfer']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//lightning-formatted-text[text()='Recruiter Transfer']</value>
      <webElementGuid>b80ccda6-5717-4e55-820a-754cd557dab3</webElementGuid>
   </webElementProperties>
</WebElementEntity>
