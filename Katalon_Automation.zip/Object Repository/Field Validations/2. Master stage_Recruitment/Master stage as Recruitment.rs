<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Master stage as Recruitment</name>
   <tag></tag>
   <elementGuidId>c0221c24-26f8-4eb4-8523-fcb86b0c2270</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//lightning-formatted-text[contains(text(),'Recruitment')]</value>
      <webElementGuid>dee0ca8c-7eaf-4d22-89ec-b06643dd2531</webElementGuid>
   </webElementProperties>
</WebElementEntity>
