<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Primary technology field on the delivery management app</description>
   <name>Primary Technology Field</name>
   <tag></tag>
   <elementGuidId>5571544d-0efa-42d4-b9b2-a21ed4c582bf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='slds-form-element'])[7]//span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='slds-form-element'])[7]//span</value>
      <webElementGuid>50721ab7-6110-4e20-815d-9cc4771a3be2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
