<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>system information</name>
   <tag></tag>
   <elementGuidId>98a85930-dfb9-4881-baa8-a4fd15434ac0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='System Information']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='System Information']</value>
      <webElementGuid>2fc0d0e9-888a-457b-942f-de3f41e63b44</webElementGuid>
   </webElementProperties>
</WebElementEntity>
