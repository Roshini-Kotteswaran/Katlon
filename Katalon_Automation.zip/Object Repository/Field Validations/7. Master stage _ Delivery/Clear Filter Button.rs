<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Clear filter button on the delivery management app.</description>
   <name>Clear Filter Button</name>
   <tag></tag>
   <elementGuidId>c7d6e8cf-a32d-4714-a704-631fdde5ec77</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[text()='Clear Filters']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[text()='Clear Filters']</value>
      <webElementGuid>7805a20c-0548-4273-9cc6-4b054a5cef67</webElementGuid>
   </webElementProperties>
</WebElementEntity>
