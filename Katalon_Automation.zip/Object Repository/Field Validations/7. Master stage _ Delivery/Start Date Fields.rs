<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Start Date field on the deliery record.</description>
   <name>Start Date Fields</name>
   <tag></tag>
   <elementGuidId>96617eef-56f7-4bc4-a02a-0ba0dc38d13d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='Start Date'])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='Start Date'])[3]</value>
      <webElementGuid>c4c0bb79-e386-4205-bde9-ddb282ad179c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
