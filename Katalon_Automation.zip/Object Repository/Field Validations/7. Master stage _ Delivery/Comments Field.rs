<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Comment field on the delivery record.</description>
   <name>Comments Field</name>
   <tag></tag>
   <elementGuidId>6226f782-ef72-4d6b-be24-2b7b1d6e1f0d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='Comments'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='Comments'])[2]</value>
      <webElementGuid>4264edec-ca2e-4e87-bf7d-0fc382763420</webElementGuid>
   </webElementProperties>
</WebElementEntity>
