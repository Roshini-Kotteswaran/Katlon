<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Delivery_masterstage</name>
   <tag></tag>
   <elementGuidId>d94996c5-6303-4736-8279-67b332cfae8c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@slot = 'output' and (text() = 'Staging' or . = 'Staging')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@slot = 'output' and (text() = 'Staging' or . = 'Staging')]</value>
      <webElementGuid>d582cb8f-06f9-46b8-a616-16794514c226</webElementGuid>
   </webElementProperties>
</WebElementEntity>
