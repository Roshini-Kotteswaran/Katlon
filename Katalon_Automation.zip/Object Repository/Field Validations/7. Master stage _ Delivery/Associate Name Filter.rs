<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Associate name filter on the delivery management app.</description>
   <name>Associate Name Filter</name>
   <tag></tag>
   <elementGuidId>f5acdce4-7454-4a1f-929c-1ef6818da00c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//label[text()='Associate Name Filter'])</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//label[text()='Associate Name Filter'])</value>
      <webElementGuid>bcfe8779-8a42-4b35-a1c7-c2e5a9bda664</webElementGuid>
   </webElementProperties>
</WebElementEntity>
