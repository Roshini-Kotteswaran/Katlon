<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Cost Attribution field on the delivery management app.</description>
   <name>Cost Attribution Field DM App</name>
   <tag></tag>
   <elementGuidId>752b7923-5e01-4eeb-9402-cae003bd2eef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='Cost Attribution']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='Cost Attribution']</value>
      <webElementGuid>1b5fead7-39e0-4440-ab4d-decf6f516641</webElementGuid>
   </webElementProperties>
</WebElementEntity>
