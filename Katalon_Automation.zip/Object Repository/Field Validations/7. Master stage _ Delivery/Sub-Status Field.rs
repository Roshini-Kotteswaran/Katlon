<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Sub-status field on the delivery management app.</description>
   <name>Sub-Status Field</name>
   <tag></tag>
   <elementGuidId>8d2575c8-466b-4253-a953-64c6acc5e5da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='Sub-status']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='Sub-status']</value>
      <webElementGuid>69554e33-a3fc-4eb9-aed5-2b8bcd8479c0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
