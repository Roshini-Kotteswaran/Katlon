<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Delivery Stage field on the delivery record.</description>
   <name>Delivery Stage Field</name>
   <tag></tag>
   <elementGuidId>90d6f244-b497-4354-a067-97d12a03d11b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='Delivery Stage']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='Delivery Stage']</value>
      <webElementGuid>ad9c82d5-02db-49c2-ad4d-ad416b176a1a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
