<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Contact Name on the table in the delivery management app.</description>
   <name>Contact Name Delivery app</name>
   <tag></tag>
   <elementGuidId>06003206-36e7-4535-9c96-857c9ea79502</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//table[contains(@class, 'buffer table')]//td[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//table[contains(@class, 'buffer table')]//td[2]</value>
      <webElementGuid>919384b8-6aca-4261-b3c5-86d51f07fe9e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
