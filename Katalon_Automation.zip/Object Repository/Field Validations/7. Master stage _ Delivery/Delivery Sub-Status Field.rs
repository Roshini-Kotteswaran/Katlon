<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Delivery Sub-Status field on the delivery record.</description>
   <name>Delivery Sub-Status Field</name>
   <tag></tag>
   <elementGuidId>a48b5df3-c37f-494d-b7cf-eab053737161</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='Delivery Sub-status'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='Delivery Sub-status'])[2]</value>
      <webElementGuid>b03edd41-2455-4156-bc7f-f93e853ce4df</webElementGuid>
   </webElementProperties>
</WebElementEntity>
