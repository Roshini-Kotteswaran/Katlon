<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Submit button on the delivery management app.</description>
   <name>Submit Button</name>
   <tag></tag>
   <elementGuidId>9d1f4736-58eb-4b80-9cf3-0156bcc0b282</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[text()='Submit']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[text()='Submit']</value>
      <webElementGuid>b077720a-3c21-49fc-9ac6-a723b0455ba6</webElementGuid>
   </webElementProperties>
</WebElementEntity>
