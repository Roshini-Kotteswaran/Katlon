<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Delivery status as Ready</name>
   <tag></tag>
   <elementGuidId>c12487c7-54f1-4a74-92d4-d78679ef6ae9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='Ready']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='Ready']</value>
      <webElementGuid>fa5bd4df-0a52-4e2d-a4a3-de13d1c46e0f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
