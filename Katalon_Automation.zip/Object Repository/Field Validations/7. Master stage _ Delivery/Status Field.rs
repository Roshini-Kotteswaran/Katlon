<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Status field on the delivery management app.</description>
   <name>Status Field</name>
   <tag></tag>
   <elementGuidId>9df037c2-b43f-45ca-a025-c8ab02bc31eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='slds-form-element'])[8]//span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='slds-form-element'])[8]//span</value>
      <webElementGuid>c54f2050-29bd-4400-8aaa-19120a24f166</webElementGuid>
   </webElementProperties>
</WebElementEntity>
