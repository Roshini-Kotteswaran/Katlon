<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Until date field on the delivery management app.</description>
   <name>Until Date Field</name>
   <tag></tag>
   <elementGuidId>6541697f-619e-4279-8a41-cfd6ea364bf1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='Until Date']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='Until Date']</value>
      <webElementGuid>edc96df3-29df-4c7a-bca1-b9c4411a6423</webElementGuid>
   </webElementProperties>
</WebElementEntity>
