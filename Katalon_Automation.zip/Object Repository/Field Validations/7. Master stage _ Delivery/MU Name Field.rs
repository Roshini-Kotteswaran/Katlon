<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>MU Name field on the delivery record.</description>
   <name>MU Name Field</name>
   <tag></tag>
   <elementGuidId>5e92f6b7-f634-44db-87cb-ed3a6569e357</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='MU Name'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='MU Name'])[2]</value>
      <webElementGuid>2068fb52-1a6f-4ef9-9222-010aab8d30e8</webElementGuid>
   </webElementProperties>
</WebElementEntity>
