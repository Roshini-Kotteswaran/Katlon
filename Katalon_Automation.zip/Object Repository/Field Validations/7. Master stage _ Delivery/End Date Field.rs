<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>End Date field on the delivery record.</description>
   <name>End Date Field</name>
   <tag></tag>
   <elementGuidId>0dd69e42-bce4-43b3-a4ac-b0d25fde3a78</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='End Date'])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='End Date'])[3]</value>
      <webElementGuid>23e16ef7-7001-48da-a524-d001f4da50d2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
