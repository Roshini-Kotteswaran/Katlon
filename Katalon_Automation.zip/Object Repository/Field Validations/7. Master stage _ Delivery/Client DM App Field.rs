<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Client field on the delivery management app.</description>
   <name>Client DM App Field</name>
   <tag></tag>
   <elementGuidId>3f0f3fa4-2301-4b05-95cd-b9eb6051b090</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//label[text()='Client'])</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//label[text()='Client'])</value>
      <webElementGuid>7bb9bdfc-ca58-4e1b-bafe-82c2cfa6d834</webElementGuid>
   </webElementProperties>
</WebElementEntity>
