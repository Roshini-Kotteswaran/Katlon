<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Trainger filter field on the delivery management app.</description>
   <name>Trainer Filter Field</name>
   <tag></tag>
   <elementGuidId>f5e3cd84-a743-461f-b32d-d2e08a682e73</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='slds-form-element'])[4]//span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='slds-form-element'])[4]//span</value>
      <webElementGuid>82160262-e93d-49eb-a34e-fa50685ed08a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
