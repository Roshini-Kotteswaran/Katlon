<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Column names on the delivery management app.</description>
   <name>Column Names DM app</name>
   <tag></tag>
   <elementGuidId>d758b7ef-a838-46c7-a482-dee60ffc57cf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//table/thead/tr/th</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//table/thead/tr/th</value>
      <webElementGuid>e826122e-f7a3-4f62-b3da-0bb6747df9cc</webElementGuid>
   </webElementProperties>
</WebElementEntity>
