<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Interview columns name on the delivery management app</description>
   <name>Interviews Column Name DM App</name>
   <tag></tag>
   <elementGuidId>81645548-604c-4d8c-bdc7-6981652eb7cc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[text()='Interviews']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[text()='Interviews']</value>
      <webElementGuid>76744a57-8380-457d-9ac8-8c1ce14fbadd</webElementGuid>
   </webElementProperties>
</WebElementEntity>
