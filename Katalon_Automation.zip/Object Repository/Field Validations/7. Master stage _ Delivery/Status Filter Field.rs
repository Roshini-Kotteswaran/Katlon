<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Status filter field on the delivery management app.</description>
   <name>Status Filter Field</name>
   <tag></tag>
   <elementGuidId>8aaa6b21-d4d7-4311-9ed6-fd1e7b3ea85e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='slds-form-element'])[1]//span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='slds-form-element'])[1]//span</value>
      <webElementGuid>ca65f655-be5c-4dca-881b-3ca3065fb8a9</webElementGuid>
   </webElementProperties>
</WebElementEntity>
