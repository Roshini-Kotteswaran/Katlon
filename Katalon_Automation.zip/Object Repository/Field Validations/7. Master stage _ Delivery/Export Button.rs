<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Export button on the delivery management app.</description>
   <name>Export Button</name>
   <tag></tag>
   <elementGuidId>beac29b6-efb1-4371-97cb-3842350df1fa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[text()='Export']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[text()='Export']</value>
      <webElementGuid>1e6052cf-7256-4545-ac14-590a0c43553a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
