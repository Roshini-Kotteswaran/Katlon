<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Cost Attribution field on the delivery record.</description>
   <name>Cost Attribution Field</name>
   <tag></tag>
   <elementGuidId>c91a2da9-3e68-474e-8fa2-3ab00165eac3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='Cost Attribution'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='Cost Attribution'])[2]</value>
      <webElementGuid>4c74c5e3-3431-4be5-8cc3-92fffc51a21a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
