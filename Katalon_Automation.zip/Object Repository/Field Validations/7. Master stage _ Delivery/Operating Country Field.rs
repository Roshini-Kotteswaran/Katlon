<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Operating country field on the delivery management app.</description>
   <name>Operating Country Field</name>
   <tag></tag>
   <elementGuidId>0943dc96-9183-41cd-af43-825cd8904cc3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='slds-form-element'])[6]//span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='slds-form-element'])[6]//span</value>
      <webElementGuid>3fa6fbe6-99f8-4a31-bfce-8bf28c7d5aec</webElementGuid>
   </webElementProperties>
</WebElementEntity>
