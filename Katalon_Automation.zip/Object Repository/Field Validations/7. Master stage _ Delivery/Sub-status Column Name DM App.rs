<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Sub-status column name on the delivery management app</description>
   <name>Sub-status Column Name DM App</name>
   <tag></tag>
   <elementGuidId>79449012-3dc2-4aa9-8690-e34f93fc85e3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@title='Sub-status']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@title='Sub-status']</value>
      <webElementGuid>5892b5d4-6419-429e-a2dc-c56e7b6e7b0e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
