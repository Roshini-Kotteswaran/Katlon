<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Client field on the delivery record.</description>
   <name>Client Field</name>
   <tag></tag>
   <elementGuidId>f4c7763e-6112-4c09-88bb-1aaa613d1649</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='Client'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='Client'])[2]</value>
      <webElementGuid>dcd234bc-aae8-465c-bede-e545e04767c2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
