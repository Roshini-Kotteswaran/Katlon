<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Quick links column name on the delivery management app.</description>
   <name>Quick Links Column Name DM App</name>
   <tag></tag>
   <elementGuidId>8a1308d5-b8ea-46ae-b84f-54b96e9f6d72</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[text()='Quick Links']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[text()='Quick Links']</value>
      <webElementGuid>f4b41f16-61af-41d4-94e5-1b0799b06955</webElementGuid>
   </webElementProperties>
</WebElementEntity>
