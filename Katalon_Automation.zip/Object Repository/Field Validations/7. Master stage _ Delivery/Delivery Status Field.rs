<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Delivery Status field on the delivery record.</description>
   <name>Delivery Status Field</name>
   <tag></tag>
   <elementGuidId>56dad887-5ee5-495d-9e6d-0dd26dac2519</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='Delivery Status'])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='Delivery Status'])[3]</value>
      <webElementGuid>0d2a0890-50ed-4736-b404-b2635d759786</webElementGuid>
   </webElementProperties>
</WebElementEntity>
