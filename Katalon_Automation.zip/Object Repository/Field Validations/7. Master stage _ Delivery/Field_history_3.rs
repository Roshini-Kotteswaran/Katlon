<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Delivery Status, Delivery Sub-status, etc.</description>
   <name>Field_history_3</name>
   <tag></tag>
   <elementGuidId>09387b62-8d4b-4fd6-9bda-afcb6a9742ca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//table[contains(@class,'table_header')])[3]//thead/tr/th/lightning-primitive-header-factory/span/a/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//table[contains(@class,'table_header')])[3]//thead/tr/th/lightning-primitive-header-factory/span/a/span[2]</value>
      <webElementGuid>b556c98d-58d6-4890-8a45-f6c64ba4c7db</webElementGuid>
   </webElementProperties>
</WebElementEntity>
