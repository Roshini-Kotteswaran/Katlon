<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Effective date field on the delivery management app.</description>
   <name>Effective Date Field</name>
   <tag></tag>
   <elementGuidId>de3edfe2-81d4-40f4-a7e7-7da7d3222833</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='Effective Date']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='Effective Date']</value>
      <webElementGuid>3c7d92ac-2e77-420d-afb1-741e53018762</webElementGuid>
   </webElementProperties>
</WebElementEntity>
