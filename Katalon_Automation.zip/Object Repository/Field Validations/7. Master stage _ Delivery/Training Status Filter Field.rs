<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Training status filter field on the delivery management app.</description>
   <name>Training Status Filter Field</name>
   <tag></tag>
   <elementGuidId>bda81e14-b1e8-47f7-a1c6-5ff5c2f3aaba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='slds-form-element'])[3]//span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='slds-form-element'])[3]//span</value>
      <webElementGuid>8f8d4a6c-76fe-4885-bb15-24250fbb917b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
