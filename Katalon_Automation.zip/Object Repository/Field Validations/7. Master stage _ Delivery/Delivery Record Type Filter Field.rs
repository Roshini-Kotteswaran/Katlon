<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Delivery record type filter field on the delivery management app.</description>
   <name>Delivery Record Type Filter Field</name>
   <tag></tag>
   <elementGuidId>8a9244af-b1c9-43fa-b79f-559da336c732</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='slds-form-element'])[2]//span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='slds-form-element'])[2]//span</value>
      <webElementGuid>41cad719-3dc3-4614-94ce-2e45dcde0ae2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
