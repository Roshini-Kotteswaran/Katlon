<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Opportunity ID field on the delivery management app.</description>
   <name>Opportunity ID Field</name>
   <tag></tag>
   <elementGuidId>610a6632-884b-402a-bbcc-786b3d519164</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//label[text()='Opportunity ID'])</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//label[text()='Opportunity ID'])</value>
      <webElementGuid>8e728782-533d-4a50-a06c-9b6dff93b0e6</webElementGuid>
   </webElementProperties>
</WebElementEntity>
