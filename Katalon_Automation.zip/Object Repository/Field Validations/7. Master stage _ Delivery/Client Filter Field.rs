<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Client filter field on the delivery management app</description>
   <name>Client Filter Field</name>
   <tag></tag>
   <elementGuidId>343e9a81-9253-4338-b7d1-e1abc31ef259</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class='slds-form-element'])[5]//span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class='slds-form-element'])[5]//span</value>
      <webElementGuid>f6193d17-d0ab-4469-bbfc-382c63a475b2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
