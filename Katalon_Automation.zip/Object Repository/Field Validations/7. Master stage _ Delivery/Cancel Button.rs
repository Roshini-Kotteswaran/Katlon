<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Cancel button on the delivery management app.</description>
   <name>Cancel Button</name>
   <tag></tag>
   <elementGuidId>2064a09f-30b5-437b-a118-77f3032b4bb8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[text()='Cancel']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[text()='Cancel']</value>
      <webElementGuid>d3fe307f-b6b0-4af4-ba79-ad907ca1d7eb</webElementGuid>
   </webElementProperties>
</WebElementEntity>
