<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Interview round status as selected</name>
   <tag></tag>
   <elementGuidId>09481461-4ddd-4d87-89d9-31ac4822dcbe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//lightning-formatted-text[text()='Selected'])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//lightning-formatted-text[text()='Selected'])[3]</value>
      <webElementGuid>a638c1f3-cd23-4185-8d58-daf6b3a808bd</webElementGuid>
   </webElementProperties>
</WebElementEntity>
