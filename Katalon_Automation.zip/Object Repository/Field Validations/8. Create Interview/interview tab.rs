<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>interview tab</name>
   <tag></tag>
   <elementGuidId>9d97dc93-7841-4f2c-8eab-ef8407911b21</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[text()='Interviews']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[text()='Interviews']</value>
      <webElementGuid>d9e7ffca-3499-4115-b31e-ad2ac183eec4</webElementGuid>
   </webElementProperties>
</WebElementEntity>
