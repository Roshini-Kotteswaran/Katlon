<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>interview round status uodate field</name>
   <tag></tag>
   <elementGuidId>75decb7e-2afb-4ab2-8896-e39d01c29e5f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(),'INTR')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(),'INTR')])[3]</value>
      <webElementGuid>4404f8cd-8225-4704-9276-5d2e852e077b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
