<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>interview round tab</name>
   <tag></tag>
   <elementGuidId>0c76f2aa-9bd1-4991-9bad-565550ec0dbd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[text()='Interview Round']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[text()='Interview Round']</value>
      <webElementGuid>ee9070a4-52d3-41de-84fc-23e26193646d</webElementGuid>
   </webElementProperties>
</WebElementEntity>
