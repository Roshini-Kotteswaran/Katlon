<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>interview email</name>
   <tag></tag>
   <elementGuidId>c8516491-e12e-4281-b36a-9fad2d2b426a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//a[contains(@title,'Interview:')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//a[contains(@title,'Interview:')])[2]</value>
      <webElementGuid>4a53eda7-66ea-445b-9f74-e665dafdb0cb</webElementGuid>
   </webElementProperties>
</WebElementEntity>
