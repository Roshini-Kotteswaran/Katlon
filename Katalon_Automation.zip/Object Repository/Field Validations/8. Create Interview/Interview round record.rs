<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Interview round record</name>
   <tag></tag>
   <elementGuidId>22dc7d14-a4cb-4dde-bd99-7859a8e1ffeb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(),'INTR')])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(),'INTR')])[1]</value>
      <webElementGuid>bc9ec28e-4657-4a46-9738-5e7feea093e2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
