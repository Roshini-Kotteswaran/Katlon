<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Interview status as selected</name>
   <tag></tag>
   <elementGuidId>8a4124af-1c4c-4ee7-83c9-d2500a8e4b49</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//lightning-formatted-text[text()='Selected'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//lightning-formatted-text[text()='Selected'])[2]</value>
      <webElementGuid>ab31bd84-a431-4973-ac15-efa1af99e9dc</webElementGuid>
   </webElementProperties>
</WebElementEntity>
