<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Quick link section</name>
   <tag></tag>
   <elementGuidId>f50204cf-e698-4452-ba2a-ef379a8826fa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(text(),'Quick Links')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(text(),'Quick Links')]</value>
      <webElementGuid>04c34d1b-7a5a-4c30-b4fd-b07576e055f0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
