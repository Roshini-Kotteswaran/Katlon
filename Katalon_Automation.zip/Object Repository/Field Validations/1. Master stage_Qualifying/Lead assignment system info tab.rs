<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Lead assignment system info tab</name>
   <tag></tag>
   <elementGuidId>782f02fe-56cc-4f71-8528-087eea9b96a3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[text()='System Information'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[text()='System Information'])[2]</value>
      <webElementGuid>67767bce-afbc-41ea-9901-322aea467e8a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
