<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Marketing Tab</name>
   <tag></tag>
   <elementGuidId>b231d09a-3edf-47ce-948b-65fde7eb63af</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[text()='Marketing']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[text()='Marketing']</value>
      <webElementGuid>ad968d29-f638-4631-8bb8-e65388d6ae22</webElementGuid>
   </webElementProperties>
</WebElementEntity>
