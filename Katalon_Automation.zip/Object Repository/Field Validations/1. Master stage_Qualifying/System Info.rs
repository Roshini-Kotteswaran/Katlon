<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>System Info</name>
   <tag></tag>
   <elementGuidId>8c535c52-2ddd-40a3-99c4-fcd7dcebbc06</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='System Information']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='System Information']</value>
      <webElementGuid>5fc8c6b7-dd2f-44c0-a042-d0572786440b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
