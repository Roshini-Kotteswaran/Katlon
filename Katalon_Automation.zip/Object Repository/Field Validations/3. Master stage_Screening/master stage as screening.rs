<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>master stage as screening</name>
   <tag></tag>
   <elementGuidId>af338162-cbb9-44af-8e50-3cc7c125e8a4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@slot = 'output' and (text() = 'Screening' or . = 'Screening')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@slot = 'output' and (text() = 'Screening' or . = 'Screening')]</value>
      <webElementGuid>85cf84e0-00b9-49ef-aced-a362e5368e97</webElementGuid>
   </webElementProperties>
</WebElementEntity>
