<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>screening recruitment status change</name>
   <tag></tag>
   <elementGuidId>c1ff3ca8-2e02-4da5-9558-c9a01e6b45b3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//lightning-formatted-text[text()='Tech Screen']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//lightning-formatted-text[text()='Tech Screen']</value>
      <webElementGuid>f58e9d92-57de-4381-b9ac-94f07768f870</webElementGuid>
   </webElementProperties>
</WebElementEntity>
