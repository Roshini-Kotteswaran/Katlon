<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>screening last activity</name>
   <tag></tag>
   <elementGuidId>ef2546ba-7d56-420c-a5c5-864054d209fb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[@class='slds-form-element__static uiOutputDate'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class='slds-form-element__static uiOutputDate'])[2]</value>
      <webElementGuid>bd637039-7bac-4c7c-b021-f722a133fb05</webElementGuid>
   </webElementProperties>
</WebElementEntity>
