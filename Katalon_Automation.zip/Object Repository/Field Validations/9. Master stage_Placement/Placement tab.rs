<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Placement tab</name>
   <tag></tag>
   <elementGuidId>e0287dbe-ab37-4aa0-9285-e7a414d7aa47</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(),'Placements')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(),'Placements')])[3]</value>
      <webElementGuid>a235023e-1272-4b3d-9731-c88ce15e467f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
