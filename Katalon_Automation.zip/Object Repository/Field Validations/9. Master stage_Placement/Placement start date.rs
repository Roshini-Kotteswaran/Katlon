<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Placement start date</name>
   <tag></tag>
   <elementGuidId>8d696701-b65d-45e2-9fce-5188f63e76cf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[@class='slds-form-element__static uiOutputDate'])[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class='slds-form-element__static uiOutputDate'])[5]</value>
      <webElementGuid>18b4b918-f40f-479d-98b1-3cd296cc17dd</webElementGuid>
   </webElementProperties>
</WebElementEntity>
