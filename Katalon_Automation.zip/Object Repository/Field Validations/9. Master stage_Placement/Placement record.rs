<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Placement record</name>
   <tag></tag>
   <elementGuidId>110c31d0-ce99-4d29-bf57-a270b907b452</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(),'PLACE')])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(),'PLACE')])[4]</value>
      <webElementGuid>2ea9efed-9ed1-4a3f-b6fa-c52f2fb8b4a0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
