<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Last Placement</name>
   <tag></tag>
   <elementGuidId>eff9a06f-ab93-4497-b9c4-8d31312744cd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(),'PLACE')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(),'PLACE')])[2]</value>
      <webElementGuid>ed2648c4-5e3e-45d1-83d2-a1169b105bf5</webElementGuid>
   </webElementProperties>
</WebElementEntity>
