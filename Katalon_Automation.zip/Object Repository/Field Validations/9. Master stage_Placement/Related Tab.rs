<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Related Tab</name>
   <tag></tag>
   <elementGuidId>f18a1c79-d571-45bb-8fbc-113b979832b0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[text()='Related']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[text()='Related']</value>
      <webElementGuid>09c8e187-7b15-45ea-b03e-69e8948c2729</webElementGuid>
   </webElementProperties>
</WebElementEntity>
