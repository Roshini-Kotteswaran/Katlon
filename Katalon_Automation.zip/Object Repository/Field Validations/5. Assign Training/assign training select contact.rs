<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>assign training select contact</name>
   <tag></tag>
   <elementGuidId>6ad32456-3a15-4c16-87e8-897549478d94</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//table[@data-aura-class='uiVirtualDataTable'])[2]//tbody/tr/th/span/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//table[@data-aura-class='uiVirtualDataTable'])[2]//tbody/tr/th/span/a</value>
      <webElementGuid>d7e527b5-e4e5-4163-a233-fe3557a941fa</webElementGuid>
   </webElementProperties>
</WebElementEntity>
