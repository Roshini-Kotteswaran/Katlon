<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>additional contact details</name>
   <tag></tag>
   <elementGuidId>c4ad8513-b6b1-4840-b1a5-ca912b064ec9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='Additional Contact Details']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='Additional Contact Details']</value>
      <webElementGuid>4b22ed43-df0b-4252-8a28-1a08152947d8</webElementGuid>
   </webElementProperties>
</WebElementEntity>
