<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Assign training master stage</name>
   <tag></tag>
   <elementGuidId>f63f99ca-1026-4425-b7d1-687c5b1db340</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@slot = 'output' and (text() = 'Selected' or . = 'Selected')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@slot = 'output' and (text() = 'Selected' or . = 'Selected')]</value>
      <webElementGuid>92d47b52-548c-4d53-8c94-6c9b201a16b2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
