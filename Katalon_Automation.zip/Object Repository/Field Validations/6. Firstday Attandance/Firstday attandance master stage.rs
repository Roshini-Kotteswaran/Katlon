<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Firstday attandance master stage</name>
   <tag></tag>
   <elementGuidId>8938d286-a01c-4106-b355-9a056b8e6b65</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@slot = 'output' and (text() = 'Training' or . = 'Training')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@slot = 'output' and (text() = 'Training' or . = 'Training')]</value>
      <webElementGuid>f1ed7bf6-6cf7-4440-bec7-e693ba1e114f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
