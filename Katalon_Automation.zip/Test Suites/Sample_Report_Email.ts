<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Sample_Report_Email</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>ravishankar.n@revature.com;karthick.haribabu@revature.com;</mailRecipient>
   <numberOfRerun>1</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>d5632cf5-20cb-45f1-a9ef-3f04a2f60bae</testSuiteGuid>
   <testCaseLink>
      <guid>529f2b8a-a497-409e-b517-02380678b907</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/dummy</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>c8514869-672a-4fc5-bcf8-5e65ed71b5c5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC1_Create Lead (89960)</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>83b160ea-cdde-4ba1-a32c-dd0a2bf893e1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC2_Start Requirement (89961)</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>32da6bd5-58ef-4591-bac8-f1e10af82ae3</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>2f01dc4a-a9fa-4c1b-a2f9-4057cfdfc692</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>dc70c426-27a3-40ab-a75d-f2069bc459d8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC2_Create contact (89961)</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>8d675026-47cd-494e-a158-2d5cb3e11ffd</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>0f41f567-f8f4-4619-bba2-fd7e561e3e29</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC3_Screening (89962)</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
