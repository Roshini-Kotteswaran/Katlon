import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import org.openqa.selenium.WebElement as WebElement

WebUI.openBrowser('')

WebUI.navigateToUrl('https://rev2--revqa.sandbox.my.salesforce.com/')

WebUI.setText(findTestObject('Pages/Login Object/input_Username_username'), 'roshini.kotteswaran@revature.com.revqa')

WebUI.setEncryptedText(findTestObject('Pages/Login Object/input_Password_pw'), 'AmTvaC9WWeUBj5YU7MYS1g==')

WebUI.maximizeWindow()

WebUI.click(findTestObject('Object Repository/Record and play/Page_Login  Salesforce/input_Login'))

WebUI.navigateToUrl(GlobalVariable.Navigate_URL)

WebUI.click(findTestObject('Pages/Screening Object/Screening slots/button_Search'))

WebUI.delay(2)

WebUI.sendKeys(findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90'), 'sudeep sarkar')

TestObject global_search = findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90')

WebUI.sendKeys(global_search, Keys.chord(Keys.ENTER))

WebUI.enhancedClick(findTestObject('Pages/Delivery Object/Start Marketing Process Button/select_user'))

WebUI.enableSmartWait()

WebUI.click(findTestObject('Pages/Screening Object/Screening slots/user details button'))

WebUI.delay(2)

WebUI.doubleClick(findTestObject('Pages/Screening Object/Screening slots/login button'))

WebUI.delay(2)

WebUI.click(findTestObject('Object Repository/Record and play/Page_Home  Salesforce/div_App Launcher'))

WebUI.sendKeys(findTestObject('Pages/Login Object/input_Search apps and items_input-90'), 'Delivery Management')

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

WebUI.click(findTestObject('Pages/Delivery Object/Delivery management app/div_Delivery Management'))

WebUI.delay(3)

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

WebUI.scrollToElement(findTestObject('Field Validations/7. Master stage _ Delivery/Sub-status Column Name DM App'), 3)

WebUI.delay(3)

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

WebUI.scrollToElement(findTestObject('Field Validations/7. Master stage _ Delivery/Interviews Column Name DM App'), 2)

WebUI.delay(3)

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

WebUI.scrollToElement(findTestObject('Field Validations/7. Master stage _ Delivery/Quick Links Column Name DM App'), 3)

WebUI.delay(3)

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

//============================================================= top left fields 
String statusFilter = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Status Filter Field'))

println(statusFilter)

String drecordtypeFilter = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Delivery Record Type Filter Field'))

println(drecordtypeFilter)

String trainingstatusFilter = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Training Status Filter Field'))

println(trainingstatusFilter)

String trainerFilter = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Trainer Filter Field'))

println(trainerFilter)

String clientFilter = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Client Filter Field'))

println(clientFilter)

String operatingCountry = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Operating Country Field'))

println(operatingCountry)

String primaryTechnonogy = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Primary Technology Field'))

println(primaryTechnonogy)

String associatenameFilter = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Associate Name Filter'))

println(associatenameFilter)

if (((((((statusFilter.equals('Status Filter') && drecordtypeFilter.equals('Delivery Record Type Filter')) && trainingstatusFilter.equals(
    'Training Status Filter')) && trainerFilter.equals('Trainer Filter')) && clientFilter.equals('Client Filter')) && operatingCountry.equals(
    'Operating Country')) && primaryTechnonogy.equals('Primary Technology')) && associatenameFilter.equals('Associate Name Filter')) {
    System.out.println('Fields are displaying as expected')
} else {
    KeywordUtil.markFailed('This step intentionally failed')
}

//=============================================== top right fields
String statusField = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Status Field'))

println(statusField)

String oppID = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Opportunity ID Field'))

println(oppID)

String client = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Client DM App Field'))

println(client)

String effectiveDate = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Effective Date Field'))

println(effectiveDate)

String untilDate = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Until Date Field'))

println(untilDate)

String subStatus = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Sub-Status Field'))

println(subStatus)

String costAttribution = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Cost Attribution Field DM App'))

println(costAttribution)

if ((((((statusField.equals('Status') && oppID.equals('Opportunity ID')) && client.equals('Client')) && effectiveDate.equals(
    'Effective Date')) && untilDate.equals('Until Date')) && subStatus.equals('Sub-status')) && costAttribution.equals('Cost Attribution')) {
    System.out.println('Fields are displaying as expected')
} else {
    KeywordUtil.markFailed('This step intentionally failed')
}

//================================================================= Clear Filter
String clearFilter = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Clear Filter Button'))

println(clearFilter)

if (clearFilter.equals('Clear Filters')) {
    System.out.println('Button is displaying as expected')
} else {
    KeywordUtil.markFailed('This step intentionally failed')
}

//================================================================================== Cancel, Submit and Export
String submitButton = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Submit Button'))

println(submitButton)

String cancelButton = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Cancel Button'))

println(cancelButton)

String exportButton = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Export Button'))

println(exportButton)

if ((submitButton.equals('Submit') && cancelButton.equals('Cancel')) && exportButton.equals('Export')) {
    System.out.println('Buttons are displaying as expected')
} else {
    KeywordUtil.markFailed('This step intentionally failed')
}

//==================================================================================== Columns
TestObject tableColumn = findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Column Names DM app')

List<String> column = WebUI.findWebElements(tableColumn, 30)

List<String> columnName = new ArrayList()

for (WebElement values : column) {
    columnName.add(values.getText( //println(values.getText())
            ))
}

println(columnName)

ArrayList arrayList = new ArrayList(Arrays.asList('', 'ASSOCIATE NAME', 'RECORD TYPE', 'MARKETING START DATE', 'TRAINING TRACK', 
    'TRAINER NAME', 'GRADUATION DATE', 'MU NAME', 'STATUS', 'SUB-STATUS', 'COST ATTRIBUTION', 'OPPORTUNITY ID', 'CLIENT', 
    'EFFECTIVE DATE', 'UNTIL DATE', 'SUBMISSIONS', 'INTERVIEWS', 'COMMENTS', 'QUICK LINKS'))

if (columnName.equals(arrayList)) {
    println('Column names are displaying as expected')
} else {
    KeywordUtil.markFailed('This step intentionally failed')
}

