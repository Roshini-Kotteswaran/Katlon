import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil

WebUI.openBrowser('')

WebUI.navigateToUrl('https://rev2--revqa.sandbox.my.salesforce.com/')

WebUI.setText(findTestObject('Pages/Login Object/input_Username_username'), 'roshini.kotteswaran@revature.com.revqa')

WebUI.setEncryptedText(findTestObject('Pages/Login Object/input_Password_pw'), 'AmTvaC9WWeUBj5YU7MYS1g==')

WebUI.maximizeWindow()

WebUI.click(findTestObject('Object Repository/Pages/Delivery Object/Start Marketing Process Button/input_Login'))

//============================================'start to login as respective users'
WebUI.navigateToUrl(GlobalVariable.Navigate_URL)

WebUI.click(findTestObject('Object Repository/Pages/Screening Object/Screening slots/button_Search'))

WebUI.delay(3)

WebUI.sendKeys(findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90'), 'Tina Ervin')

TestObject global_search = findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90')

WebUI.sendKeys(global_search, Keys.chord(Keys.ENTER))

WebUI.enhancedClick(findTestObject('Pages/Delivery Object/Start Marketing Process Button/select_user'))

WebUI.enableSmartWait()

WebUI.click(findTestObject('Pages/Screening Object/Screening slots/user details button'))

//WebUI.click(findTestObject('Pages/Screening Object/Screening slots/button_Search'))
//WebUI.setText(findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90'), 'Tina Ervin')
//WebUI.click(findTestObject('Pages/Screening Object/Screening slots/user_search_result'))
//
WebUI.delay(2)

WebUI.doubleClick(findTestObject('Pages/Screening Object/Screening slots/login button'))

WebUI.delay(2)

//WebUI.sendKeys(findTestObject('Pages/Delivery Object/Start Marketing Process Button/Login Global Search bar'), 'Rosh02 Test Contact02')
//WebUI.sendKeys(global_search, Keys.chord(Keys.ENTER))
//WebUI.delay(2)
//WebUI.click(findTestObject('Object Repository/Pages/Delivery Object/Start Marketing Process Button/a_Rosh01 Test Contact01'))
WebUI.click(findTestObject('Object Repository/Pages/Screening Object/Screening slots/button_Search'))

WebUI.delay(1)

WebUI.sendKeys(findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90'), findTestData('Contact_Name').getValue(
        1, 2))

WebUI.delay(2)

global_search = findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90')

WebUI.sendKeys(global_search, Keys.chord(Keys.ENTER))

WebUI.enhancedClick(findTestObject('Pages/Screening Object/Update screening score/User_select_contact'))

WebUI.enhancedClick(findTestObject('Pages/Recruitment Action Object/Start recruitment/span_Start Process'))

WebUI.delay(2)

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

WebUI.enhancedClick(findTestObject('Object Repository/Pages/Delivery Object/Start Marketing Process Button/a_Start Marketing'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Pages/Delivery Object/Start Marketing Process Button/select_NewReady'), 
    'Ready', true)

WebUI.delay(2)

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

WebUI.mouseOver(findTestObject('Object Repository/Pages/Delivery Object/Start Marketing Process Button/button_Submit'))

WebUI.enhancedClick(findTestObject('Object Repository/Pages/Delivery Object/Start Marketing Process Button/button_Submit'))

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

//======================================== Validation
String deliverystatus = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Delivery status as Ready'))

if (deliverystatus.equals('Ready')) {
    println('Delivery status is Ready')
} else {
    KeywordUtil.markFailed('This step intentionally failed')
}

