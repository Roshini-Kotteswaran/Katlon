import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory
import org.openqa.selenium.JavascriptExecutor


WebUI.openBrowser('')

WebUI.navigateToUrl('https://rev2--revqa.sandbox.my.salesforce.com/')

WebUI.setText(findTestObject('Pages/Login Object/input_Username_username'), 'roshini.kotteswaran@revature.com.revqa')

WebUI.setEncryptedText(findTestObject('Pages/Login Object/input_Password_pw'), 'AmTvaC9WWeUBj5YU7MYS1g==')

WebUI.maximizeWindow()

WebUI.click(findTestObject('Pages/Delivery Object/Start Marketing Process Button/input_Login'))

WebUI.navigateToUrl(GlobalVariable.Navigate_URL)

WebUI.click(findTestObject('Pages/Screening Object/Screening slots/button_Search'))

WebUI.delay(2)

WebUI.sendKeys(findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90'), 'Tina Ervin')

TestObject global_search = findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90')

WebUI.sendKeys(global_search, Keys.chord(Keys.ENTER))

WebUI.enhancedClick(findTestObject('Pages/Delivery Object/Start Marketing Process Button/select_user'))

WebUI.enableSmartWait()

WebUI.click(findTestObject('Pages/Screening Object/Screening slots/user details button'))

WebUI.delay(2)

WebUI.doubleClick(findTestObject('Pages/Screening Object/Screening slots/login button'))

WebUI.delay(2)

WebUI.click(findTestObject('Object Repository/Pages/Screening Object/Screening slots/button_Search'))

WebUI.delay(1)

WebUI.sendKeys(findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90'), findTestData('Contact_Name').getValue(
        1, 2))

WebUI.delay(2)

global_search = findTestObject('Pages/Screening Object/Screening slots/input_Search_input-90')

WebUI.sendKeys(global_search, Keys.chord(Keys.ENTER))

WebUI.enhancedClick(findTestObject('Pages/Screening Object/Update screening score/User_select_contact'))

WebUI.click(findTestObject('Object Repository/Pages/Delivery Object/Start Marketing Process Button/a_Delivery'))

WebUI.delay(3)

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

WebUI.scrollToElement(findTestObject('Pages/Delivery Object/Start Marketing Process Button/a_Delivery'), 1)

WebUI.click(findTestObject('Object Repository/Pages/Delivery Object/Start Marketing Process Button/span_D-18042'))

WebUI.scrollToPosition(500, 500)

//=============================================================================
String deliverystage = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Delivery Stage Field'))

println(deliverystage)

String deliverystatus = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Delivery Status Field'))

println(deliverystatus)

String deliverysubstatus = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Delivery Sub-Status Field'))

println(deliverysubstatus)

String costattribute = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Cost Attribution Field'))

println(costattribute)

String muname = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/MU Name Field'))

println(muname)

String comments = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Comments Field'))

println(comments)

String client = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Client Field'))

println(client)

String startdate = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/Start Date Fields'))

println(startdate)

String enddate = WebUI.getText(findTestObject('Object Repository/Field Validations/7. Master stage _ Delivery/End Date Field'))

println(enddate)


//==============================================Zoom out and Screenshot

def driver = DriverFactory.getWebDriver()
 int zoomLevel = 60
 String script = "document.body.style.zoom = '${zoomLevel}%';"
((JavascriptExecutor) driver).executeScript(script)

CustomKeywords.'myPackage.Screenshots.captureScreenshot'(GlobalVariable.folderPath, GlobalVariable.screenshot)

//====================================================Validations
if (((((((deliverystage.equals('Delivery Stage') && deliverystatus.equals('Delivery Status')) && deliverysubstatus.equals(
    'Delivery Sub-status')) && costattribute.equals('Cost Attribution')) && muname.equals('MU Name')) && comments.equals(
    'Comments')) && startdate.equals('Start Date')) && enddate.equals('End Date')) {
    println('Valid Field Name')
} else {
    KeywordUtil.markFailed('This step intentionally failed')
}

